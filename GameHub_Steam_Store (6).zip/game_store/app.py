from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import sqlite3
import os
import random
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = 'steam-like-secret-key-2024-change-in-prod'
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 2 * 1024 * 1024

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# ───────────────────────── DB ─────────────────────────

def get_db():
    conn = sqlite3.connect('game_store.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        display_name TEXT,
        bio TEXT DEFAULT '',
        avatar TEXT DEFAULT '',
        balance REAL DEFAULT 1000.0,
        is_admin INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS games (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        description TEXT,
        short_description TEXT,
        price REAL NOT NULL,
        discount INTEGER DEFAULT 0,
        image_url TEXT,
        header_image TEXT,
        screenshots TEXT DEFAULT '',
        genre TEXT,
        developer TEXT,
        publisher TEXT,
        release_date TEXT,
        tags TEXT,
        rating REAL DEFAULT 0,
        reviews_count INTEGER DEFAULT 0,
        system_requirements TEXT,
        age_rating TEXT DEFAULT '12+',
        featured INTEGER DEFAULT 0
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS library (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        purchase_date TEXT DEFAULT CURRENT_TIMESTAMP,
        playtime INTEGER DEFAULT 0,
        favorite INTEGER DEFAULT 0,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id),
        UNIQUE(user_id, game_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS wishlist (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        added_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id),
        UNIQUE(user_id, game_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS cart (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id),
        UNIQUE(user_id, game_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS reviews (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        rating INTEGER CHECK(rating >= 1 AND rating <= 5),
        text TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS friends (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, friend_id INTEGER,
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id),
        FOREIGN KEY (friend_id) REFERENCES users(id),
        UNIQUE(user_id, friend_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS activity (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        action TEXT,
        details TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS news (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        body TEXT,
        image_url TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS gifts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_user INTEGER, to_user INTEGER, game_id INTEGER,
        message TEXT DEFAULT '',
        status TEXT DEFAULT 'pending',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (from_user) REFERENCES users(id),
        FOREIGN KEY (to_user) REFERENCES users(id),
        FOREIGN KEY (game_id) REFERENCES games(id)
    )''')


    c.execute('''CREATE TABLE IF NOT EXISTS achievements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        title TEXT NOT NULL,
        description TEXT,
        icon TEXT DEFAULT 'fa-trophy',
        points INTEGER DEFAULT 10
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS user_achievements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, achievement_id INTEGER,
        unlocked_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, achievement_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS promo_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        discount_percent INTEGER DEFAULT 10,
        max_uses INTEGER DEFAULT 100,
        used_count INTEGER DEFAULT 0,
        active INTEGER DEFAULT 1,
        expires_at TEXT
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS notifications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        title TEXT,
        body TEXT,
        link TEXT DEFAULT '',
        is_read INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS review_likes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, review_id INTEGER,
        UNIQUE(user_id, review_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS purchase_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER, game_id INTEGER,
        price_paid REAL,
        promo_code TEXT DEFAULT '',
        purchased_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS collections (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        slug TEXT UNIQUE,
        title TEXT,
        description TEXT,
        image_url TEXT DEFAULT ''
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS collection_games (
        collection_id INTEGER, game_id INTEGER,
        UNIQUE(collection_id, game_id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS guides (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_id INTEGER, user_id INTEGER,
        title TEXT, body TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS subscriptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER UNIQUE,
        active INTEGER DEFAULT 1,
        started_at TEXT DEFAULT CURRENT_TIMESTAMP,
        expires_at TEXT
    )''')

    try:
        c.execute("ALTER TABLE users ADD COLUMN status TEXT DEFAULT 'online'")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE games ADD COLUMN trailer_url TEXT DEFAULT ''")
    except Exception:
        pass
    try:
        c.execute("ALTER TABLE games ADD COLUMN is_preorder INTEGER DEFAULT 0")
    except Exception:
        pass


    conn.commit()
    seed_games(conn)
    seed_extra(conn)
    seed_news(conn)
    conn.close()

def seed_games(conn):
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM games')
    if c.fetchone()[0] > 0:
        return

    games = [
        # ── existing expanded ──
        dict(title='Cyber Odyssey 2077', short_description='Масштабная RPG в киберпанк-мире будущего с открытым городом и глубокой кастомизацией.',
             description='''Погрузитесь в неонный мегаполис будущего, где корпорации правят миром, а хакеры сражаются за свободу. Cyber Odyssey 2077 — это масштабная RPG с открытым миром, глубокой сюжетной линией и невероятной кастомизацией персонажа.

Выберите свой путь: станьте легендарным наёмником, хакером, корпоративным агентом или уличным воином. Каждый выбор влияет на развитие истории и открывает уникальные возможности.

Графика нового поколения, динамичный геймплей и саундтрек от лучших электронных музыкантов сделают ваше приключение незабываемым.''',
             price=2499, discount=20,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/813780/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg',
             genre='RPG, Action, Open World', developer='Neon Studios', publisher='Future Games',
             release_date='2024-11-15', tags='Киберпанк,RPG,Открытый мир,Экшен', rating=4.6, reviews_count=12847,
             system_requirements='ОС: Windows 10/11\nПроцессор: Intel i5-8400 / AMD Ryzen 5 2600\nОЗУ: 12 GB\nВидеокарта: GTX 1060 6GB / RX 580\nМесто: 70 GB SSD',
             age_rating='18+', featured=1),

        dict(title='Empire of Legends', short_description='Эпическая RTS с глубокой экономикой, дипломатией и масштабными сражениями.',
             description='''Станьте правителем великой империи в этой эпической стратегии в реальном времени. Стройте города, исследуйте технологии, заключайте союзы и ведите армии в грандиозные сражения.

Empire of Legends предлагает глубокую экономическую систему, дипломатию и тактические бои. Более 20 уникальных цивилизаций с собственной историей, юнитами и технологиями.

Мультиплеер до 8 игроков, кооперативный режим и бесконечные сценарии ждут вас.''',
             price=1899, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/813780/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/813780/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/813780/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg',
             genre='Strategy, RTS', developer='Horizon Interactive', publisher='Strategy Masters',
             release_date='2023-06-20', tags='Стратегия,RTS,Мультиплеер,Экономика', rating=4.4, reviews_count=8932,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i3-8100\nОЗУ: 8 GB\nВидеокарта: GTX 1050\nМесто: 25 GB',
             age_rating='12+', featured=0),

        dict(title='Shadow Protocol', short_description='Тактический стелс-экшен с свободой выбора подхода к каждой миссии.',
             description='''Стелс-экшен нового поколения. Вы — элитный агент секретной организации, выполняющий задания в самых опасных точках планеты.

Используйте тени, гаджеты и тактическое мышление, чтобы оставаться незамеченным. Или выбирайте агрессивный стиль — выбор за вами. Каждая миссия имеет множество путей прохождения.

Реалистичная физика, продвинутый ИИ противников и кинематографичная подача делают Shadow Protocol одной из лучших стелс-игр последних лет.''',
             price=2199, discount=35,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg',
             genre='Stealth, Action, Adventure', developer='Silent Forge', publisher='Action House',
             release_date='2024-03-08', tags='Стелс,Экшен,Тактика,Одиночная', rating=4.8, reviews_count=15621,
             system_requirements='ОС: Windows 10/11\nПроцессор: Intel i5-9600K\nОЗУ: 16 GB\nВидеокарта: RTX 2060\nМесто: 55 GB SSD',
             age_rating='16+', featured=1),

        dict(title='Stellar Frontiers', short_description='Космическая симуляция с открытой галактикой, торговлей и исследованиями.',
             description='''Исследуйте бескрайний космос в этой космической симуляции. Управляйте собственным кораблём, торгуйте ресурсами, сражайтесь с пиратами и открывайте новые миры.

Stellar Frontiers предлагает процедурно генерируемую галактику с миллионами звёздных систем. Стройте базы, улучшайте корабль, присоединяйтесь к фракциям или создавайте собственную империю.

Поддержка VR, глубокая система крафта и живая экономика делают игру по-настоящему захватывающей.''',
             price=1599, discount=15,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/359320/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/359320/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/359320/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg',
             genre='Simulation, Space, Open World', developer='Orbit Labs', publisher='Cosmic Entertainment',
             release_date='2022-12-01', tags='Космос,Симулятор,Открытый мир,VR', rating=4.3, reviews_count=22104,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i5-8400\nОЗУ: 12 GB\nВидеокарта: GTX 1660\nМесто: 40 GB',
             age_rating='12+', featured=0),

        dict(title='Mystic Realms Online', short_description='Классическая MMORPG с рейдами, PvP и огромным фэнтези-миром.',
             description='''Классическая MMORPG в мире магии и приключений. Создайте героя одного из 8 классов, исследуйте огромный мир, сражайтесь с боссами и участвуйте в PvP-аренах.

Mystic Realms Online предлагает традиционный геймплей с современными удобствами: автоматический лут, улучшенный интерфейс и регулярные обновления контента.

Гильдии, рейды на 40 человек, система репутации и сезонные события — всё это ждёт вас в мире Mystic Realms.''',
             price=0, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/306130/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/306130/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/306130/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg',
             genre='MMORPG, Fantasy', developer='Realm Studios', publisher='Online Worlds',
             release_date='2021-09-15', tags='MMORPG,Фэнтези,PvP,Бесплатная', rating=4.1, reviews_count=45678,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i3-6100\nОЗУ: 8 GB\nВидеокарта: GTX 960\nМесто: 35 GB',
             age_rating='12+', featured=1),

        dict(title='Velocity Rush', short_description='Реалистичный гоночный симулятор с лицензированными авто и трассами.',
             description='''Адреналиновые гонки на суперкарах по трассам всего мира. Реалистичная физика, детализированные автомобили и динамическая погода создают ощущение настоящего вождения.

Более 50 лицензированных автомобилей, 20 трасс и режим карьеры с глубокой прогрессией. Мультиплеер с рейтинговой системой и кастомными чемпионатами.

Поддержка руля и VR для максимального погружения.''',
             price=2799, discount=10,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg',
             genre='Racing, Simulation', developer='Speed Dynamics', publisher='Racing Pro',
             release_date='2024-05-22', tags='Гонки,Симулятор,Мультиплеер,VR', rating=4.5, reviews_count=9876,
             system_requirements='ОС: Windows 10/11\nПроцессор: Intel i7-8700\nОЗУ: 16 GB\nВидеокарта: RTX 3060\nМесто: 80 GB SSD',
             age_rating='6+', featured=0),

        dict(title='Darkwood Legacy', short_description='Survival-horror с дневным исследованием и ночной обороной убежища.',
             description='''Атмосферный survival-horror в тёмном лесу, полном тайн и ужасов. Днём вы исследуете локации и собираете ресурсы, ночью — обороняете убежище от монстров.

Darkwood Legacy сочетает элементы выживания, исследования и психологического хоррора. Нет HUD, минималистичный интерфейс и полное погружение в атмосферу страха.

Процедурная генерация локаций, уникальные события и несколько концовок делают каждое прохождение особенным.''',
             price=999, discount=50,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg',
             genre='Horror, Survival, Indie', developer='Forest Night Games', publisher='Indie Horror Collective',
             release_date='2023-10-31', tags='Хоррор,Выживание,Инди,Атмосфера', rating=4.7, reviews_count=5432,
             system_requirements='ОС: Windows 7/10\nПроцессор: Intel i3\nОЗУ: 4 GB\nВидеокарта: GTX 750\nМесто: 4 GB',
             age_rating='16+', featured=0),

        dict(title='Pixel Legends', short_description='Пиксельная JRPG с пошаговыми боями и ностальгической атмосферой.',
             description='''Очаровательная пиксельная RPG в духе классики 90-х. Исследуйте мир, собирайте партию героев, сражайтесь в пошаговых боях и раскрывайте древние тайны.

Pixel Legends — это дань уважения золотой эре японских RPG с современной удобной системой и красивым пиксель-артом.

Более 40 часов основного сюжета, побочные квесты, крафт и система классов ждут любителей жанра.''',
             price=799, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg',
             genre='RPG, Indie, Pixel Art', developer='Retro Pixel Studio', publisher='Indie Gems',
             release_date='2024-01-18', tags='Пиксель-арт,JRPG,Инди,Пошаговая', rating=4.9, reviews_count=3210,
             system_requirements='ОС: Windows 7+\nПроцессор: любой\nОЗУ: 2 GB\nВидеокарта: интегрированная\nМесто: 1 GB',
             age_rating='6+', featured=1),

        dict(title='Warzone Tactics', short_description='Тактическая пошаговая стратегия с перманентной смертью и развитием базы.',
             description='''Тактическая стратегия в духе классических XCOM. Управляйте отрядом спецназа, выполняйте миссии по всему миру и развивайте базу.

Каждый боец уникален, перманентная смерть делает каждое решение критическим. Глубокая система кастомизации оружия и брони, процедурные миссии и кампания с ветвящимся сюжетом.

Warzone Tactics — это напряжённые пошаговые бои, где тактика решает всё.''',
             price=1699, discount=25,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/268500/header.jpg',
             genre='Strategy, Tactical, Turn-based', developer='Tactical Minds', publisher='Strategy Core',
             release_date='2023-08-14', tags='Тактика,Пошаговая,Стратегия,XCOM-like', rating=4.6, reviews_count=11234,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i5-8400\nОЗУ: 8 GB\nВидеокарта: GTX 1050 Ti\nМесто: 20 GB',
             age_rating='16+', featured=0),

        dict(title='Ocean Depths', short_description='Расслабляющее исследование океанских глубин на исследовательской субмарине.',
             description='''Исследуйте глубины океана в этой атмосферной приключенческой игре. Управляйте исследовательской субмариной, изучайте морских обитателей и раскрывайте тайны затонувших цивилизаций.

Красивая графика, расслабляющий саундтрек и элементы выживания создают уникальный опыт. Собирайте образцы, улучшайте оборудование и углубляйтесь всё дальше в бездну.''',
             price=1299, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/264710/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/264710/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/264710/header.jpg',
             genre='Adventure, Exploration, Simulation', developer='Deep Blue Interactive', publisher='Calm Games',
             release_date='2024-07-04', tags='Океан,Исследование,Релакс,Симулятор', rating=4.4, reviews_count=4567,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i5\nОЗУ: 8 GB\nВидеокарта: GTX 1060\nМесто: 15 GB',
             age_rating='6+', featured=0),

        dict(title='Neon Drift', short_description='Аркадные неоновые гонки с дрифтом и кастомизацией болидов.',
             description='''Аркадные гонки в неоновом киберпанк-городе. Дрифтуйте по ночным улицам, соревнуйтесь с лучшими райдерами и кастомизируйте свой болид.

Быстрый геймплей, яркая визуальная эстетика и энергичный саундтрек. Режимы: карьера, тайм-атака, мультиплеер и кастомные трассы.''',
             price=899, discount=30,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg',
             genre='Racing, Arcade, Cyberpunk', developer='Neon Speed', publisher='Arcade Force',
             release_date='2023-11-28', tags='Гонки,Аркада,Киберпанк,Дрифт', rating=4.2, reviews_count=6789,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i3\nОЗУ: 6 GB\nВидеокарта: GTX 960\nМесто: 8 GB',
             age_rating='6+', featured=0),

        dict(title='Kingdom Builder', short_description='Средневековый city-builder с элементами стратегии и дипломатии.',
             description='''Стройте и развивайте своё средневековое королевство. Управляйте ресурсами, стройте здания, обучайте армию и защищайтесь от врагов.

Kingdom Builder сочетает элементы city-builder и стратегии. Сезоны влияют на экономику, жители имеют свои потребности, а дипломатия открывает новые возможности.''',
             price=1499, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg',
             genre='Simulation, Strategy, City Builder', developer='Castle Craft', publisher='Builder Games',
             release_date='2022-04-12', tags='Сити-билдер,Средневековье,Стратегия,Симулятор', rating=4.3, reviews_count=8901,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i5\nОЗУ: 8 GB\nВидеокарта: GTX 1050\nМесто: 12 GB',
             age_rating='6+', featured=0),

        # ── NEW GAMES ──
        dict(title='Blade of the Ancients', short_description='Экшен-RPG с динамичными боями на мечах в мире древних богов.',
             description='''Станьте избранным воином в мире, где древние боги пробудились ото сна. Blade of the Ancients — это зрелищный экшен с глубокой боевой системой, комбо-атаками и кастомизацией оружия.

Исследуйте огромный открытый мир, сражайтесь с эпическими боссами и раскрывайте тайны забытой цивилизации. Система навыков позволяет создать уникальный стиль боя.

Поддержка кооператива до 4 игроков.''',
             price=2299, discount=15,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg&sat=-50',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg&sat=-50',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/294100/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/306130/header.jpg',
             genre='Action, RPG, Open World', developer='Mythic Forge', publisher='Epic Realms',
             release_date='2024-09-01', tags='Экшен,RPG,Кооператив,Босс-файт', rating=4.5, reviews_count=7654,
             system_requirements='ОС: Windows 10/11\nПроцессор: Intel i5-9600K\nОЗУ: 16 GB\nВидеокарта: RTX 2070\nМесто: 60 GB SSD',
             age_rating='16+', featured=1),

        dict(title='Puzzle Dimensions', short_description='Уникальные 3D-головоломки с изменением перспективы и гравитации.',
             description='''Puzzle Dimensions переворачивает представление о головоломках. Меняйте перспективу, управляйте гравитацией и находите нестандартные решения.

Более 100 уровней возрастающей сложности, редактор уровней и мастерская сообщества. Минималистичный дизайн и атмосферный саундтрек помогают сосредоточиться.

Идеально для любителей Portal, The Witness и Superliminal.''',
             price=699, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/620/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/620/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/620/header.jpg',
             genre='Puzzle, Indie', developer='Mind Bend Studio', publisher='Puzzle Works',
             release_date='2023-03-15', tags='Головоломки,Инди,3D,Креатив', rating=4.8, reviews_count=4321,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i3\nОЗУ: 4 GB\nВидеокарта: GTX 750\nМесто: 3 GB',
             age_rating='6+', featured=0),

        dict(title='Football Manager 2025', short_description='Самый детальный футбольный менеджер с обновлённой тактикой и 3D-матчами.',
             description='''Возьмите под контроль любой клуб мира. Football Manager 2025 предлагает невероятную глубину: трансферы, тактика, тренировки, молодёжная академия и взаимодействие с прессой.

Улучшенный 3D-движок матчей, расширенная аналитика и новая система развития игроков. Более 50 лиг и тысячи реальных клубов с актуальными составами.

Мечта любого футбольного фаната.''',
             price=1999, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/1506830/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/1908720/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/1908720/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1908720/header.jpg',
             genre='Sports, Simulation, Management', developer='Sports Interactive', publisher='SEGA',
             release_date='2024-11-08', tags='Футбол,Менеджер,Симулятор,Спорт', rating=4.7, reviews_count=18900,
             system_requirements='ОС: Windows 10/11\nПроцессор: Intel i5\nОЗУ: 8 GB\nВидеокарта: GTX 1050\nМесто: 7 GB',
             age_rating='6+', featured=1),

        dict(title='Zombie Siege', short_description='Кооперативный survival от 1 до 4 игроков в мире зомби-апокалипсиса.',
             description='''Выживите в мире, поглощённом зомби. Zombie Siege — это напряжённый кооперативный шутер с элементами крафта и строительства базы.

День — исследуйте, собирайте ресурсы, укрепляйте укрытие. Ночь — отбивайте волны нежити. Перманентная смерть, процедурные карты и бесконечный режим.

Поддержка split-screen и онлайн-коопа.''',
             price=1199, discount=40,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg&hue=30',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg&hue=30',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg',
             genre='Survival, Shooter, Co-op', developer='Undead Labs', publisher='Horror Interactive',
             release_date='2023-05-19', tags='Зомби,Кооп,Выживание,Шутер', rating=4.2, reviews_count=9870,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i5-8400\nОЗУ: 12 GB\nВидеокарта: GTX 1060\nМесто: 30 GB',
             age_rating='18+', featured=0),

        dict(title='Chess Masters Pro', short_description='Профессиональный шахматный движок с обучением и онлайн-турнирами.',
             description='''Chess Masters Pro — это полноценный шахматный клиент для игроков любого уровня. Мощный движок, анализ партий, библиотека дебютов и интерактивные уроки.

Играйте онлайн с рейтинговой системой, участвуйте в турнирах, решайте тактические задачи. Режим «от первого лица» и красивые 3D-доски.

Интеграция с Lichess и Chess.com.''',
             price=499, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/225340/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/653530/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/653530/header.jpg',
             genre='Board, Strategy, Puzzle', developer='Grandmaster Soft', publisher='Mind Sports',
             release_date='2022-08-01', tags='Шахматы,Стратегия,Онлайн,Обучение', rating=4.6, reviews_count=5430,
             system_requirements='ОС: Windows 7+\nПроцессор: любой\nОЗУ: 2 GB\nВидеокарта: интегрированная\nМесто: 500 MB',
             age_rating='6+', featured=0),

        dict(title='Sky Pirates', short_description='Приключения в небесных архипелагах: воздушные бои, торговля и исследование.',
             description='''Мир парящих островов и воздушных кораблей. Sky Pirates позволяет стать капитаном собственного дирижабля: исследуйте архипелаги, торгуйте, сражайтесь с пиратами и открывайте древние руины.

Динамичная экономика, кастомизация корабля, система репутации фракций. Одиночная кампания и PvP-арены.

Красивый арт-стиль и оркестровый саундтрек.''',
             price=1399, discount=20,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/508440/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/359320/header.jpg',
             genre='Adventure, Action, Open World', developer='Cloud Sail Studio', publisher='Adventure Inc',
             release_date='2024-02-14', tags='Пираты,Небо,Приключения,Открытый мир', rating=4.4, reviews_count=6120,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i5\nОЗУ: 8 GB\nВидеокарта: GTX 1060\nМесто: 25 GB',
             age_rating='12+', featured=0),

        dict(title='Code Breaker', short_description='Хакерский симулятор: взламывайте системы, пишите скрипты, оставайтесь незамеченными.',
             description='''Почувствуйте себя элитным хакером. Code Breaker предлагает реалистичную симуляцию взлома: командная строка, написание эксплойтов, социальная инженерия и слежка.

Кампания из 20 миссий с ветвящимся сюжетом. Режим песочницы с процедурными целями. Обучение программированию через геймплей.

Вдохновлено Uplink, Hacknet и Mr. Robot.''',
             price=899, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/365450/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/365450/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/365450/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg',
             genre='Simulation, Indie, Hacking', developer='Terminal Games', publisher='Cyber Soft',
             release_date='2023-09-22', tags='Хакер,Симулятор,Инди,Киберпанк', rating=4.5, reviews_count=3890,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i3\nОЗУ: 4 GB\nВидеокарта: интегрированная\nМесто: 2 GB',
             age_rating='12+', featured=0),

        dict(title='Mech Arena Online', short_description='Бесплатный PvP-шутер на гигантских мехах с глубокой кастомизацией.',
             description='''Сядьте в кабину боевого меха и выйдите на арену. Mech Arena Online — это бесплатный командный шутер 6v6 с разрушаемым окружением и модульной кастомизацией машин.

Более 30 каркасов мехов, сотни модулей оружия и брони. Сезонный боевой пропуск, рейтинговые матчи и клановые войны.

Честная модель монетизации: платите только за косметику.''',
             price=0, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/374320/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/1237970/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/1237970/header.jpg',
             genre='Shooter, PvP, Free-to-Play', developer='Titan Forge', publisher='Online Arena',
             release_date='2024-06-10', tags='Мехи,PvP,Бесплатная,Шутер', rating=4.0, reviews_count=23400,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i5-8400\nОЗУ: 12 GB\nВидеокарта: GTX 1660\nМесто: 45 GB',
             age_rating='12+', featured=1),

        dict(title='Garden Stories', short_description='Уютный симулятор садоводства с элементами повествования и крафта.',
             description='''Создайте сад своей мечты. Garden Stories — это расслабляющий симулятор, где вы выращиваете растения, украшаете участок и знакомитесь с жителями соседней деревни.

Смена времён года, редкие семена, мини-игры и трогательные истории персонажей. Нет таймеров и pay-to-win — играйте в своём темпе.

Идеально для вечернего отдыха.''',
             price=599, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg',
             genre='Simulation, Casual, Indie', developer='Cozy Pixel', publisher='Calm Games',
             release_date='2023-04-05', tags='Сад,Уют,Казуал,Симулятор', rating=4.7, reviews_count=8765,
             system_requirements='ОС: Windows 10\nПроцессор: любой\nОЗУ: 4 GB\nВидеокарта: интегрированная\nМесто: 3 GB',
             age_rating='6+', featured=0),

        dict(title='Dungeon Crawler X', short_description='Хардкорный roguelike с процедурной генерацией подземелий и перманентной смертью.',
             description='''Спуститесь в бесконечные подземелья. Dungeon Crawler X — это хардкорный roguelike: каждый забег уникален, смерть окончательна, а удача и навык решают всё.

Сотни предметов, десятки классов и врагов, система мутаций. Еженедельные челленджи и таблица лидеров.

Вдохновлено Hades, Dead Cells и Binding of Isaac.''',
             price=999, discount=25,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg&sat=-100',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg&sat=-100',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/814380/header.jpg',
             genre='Roguelike, Action, Indie', developer='Pixel Depth', publisher='Indie Gems',
             release_date='2024-08-20', tags='Roguelike,Хардкор,Инди,Процедурная', rating=4.6, reviews_count=4560,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i3\nОЗУ: 4 GB\nВидеокарта: GTX 750\nМесто: 2 GB',
             age_rating='12+', featured=0),

        dict(title='Rally Championship', short_description='Реалистичные раллийные гонки по грунтовым, снежным и асфальтовым трассам.',
             description='''Почувствуйте адреналин ралли. Rally Championship предлагает детальную физику, разрушаемые автомобили и трассы, созданные по реальным спецучасткам.

Карьера с командами, спонсорами и апгрейдами. Онлайн-чемпионаты и режим тайм-атаки. Поддержка руля и педалей.

Грязь, снег, дождь — погода влияет на сцепление.''',
             price=1799, discount=10,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/1085660/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/1085660/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/1085660/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/1551360/header.jpg',
             genre='Racing, Simulation, Sports', developer='Dirt Track Studios', publisher='Racing Pro',
             release_date='2023-12-07', tags='Ралли,Гонки,Симулятор,Реализм', rating=4.4, reviews_count=7230,
             system_requirements='ОС: Windows 10/11\nПроцессор: Intel i5-9600K\nОЗУ: 12 GB\nВидеокарта: RTX 2060\nМесто: 50 GB SSD',
             age_rating='6+', featured=0),

        dict(title='Void Explorers', short_description='Кооперативное исследование космических аномалий на космическом корабле.',
             description='''Соберите экипаж и отправьтесь к краю известной вселенной. Void Explorers — кооперативная игра на 1–4 игрока, где каждый член экипажа выполняет свою роль: пилот, инженер, учёный, стрелок.

Процедурные сектора, случайные события, апгрейды корабля. Перманентная потеря прогресса при гибели корабля добавляет напряжение.

Отличный голосовой чат и внутриигровые инструменты коммуникации.''',
             price=1499, discount=0,
             image_url='https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg',
             header_image='https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg',
             screenshots='https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg,https://cdn.cloudflare.steamstatic.com/steam/apps/359320/header.jpg',
             genre='Co-op, Adventure, Space', developer='Crew Labs', publisher='Cosmic Entertainment',
             release_date='2024-04-18', tags='Космос,Кооп,Исследование,Команда', rating=4.5, reviews_count=5670,
             system_requirements='ОС: Windows 10\nПроцессор: Intel i5\nОЗУ: 8 GB\nВидеокарта: GTX 1060\nМесто: 20 GB',
             age_rating='12+', featured=0),
    ]

    for g in games:
        c.execute('''INSERT INTO games (title, description, short_description, price, discount,
                     image_url, header_image, screenshots, genre, developer, publisher,
                     release_date, tags, rating, reviews_count, system_requirements, age_rating, featured)
                     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                  (g['title'], g['description'], g['short_description'], g['price'], g['discount'],
                   g['image_url'], g['header_image'], g.get('screenshots', ''), g['genre'],
                   g['developer'], g['publisher'], g['release_date'], g['tags'],
                   g['rating'], g['reviews_count'], g['system_requirements'],
                   g.get('age_rating', '12+'), g.get('featured', 0)))
    conn.commit()

def seed_news(conn):
    c = conn.cursor()
    c.execute('SELECT COUNT(*) FROM news')
    if c.fetchone()[0] > 0:
        return
    news_items = [
        ('Летняя распродажа началась!', 'Скидки до 50% на сотни игр. Не пропустите лучшие предложения сезона. Акция действует до конца месяца.', 'https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg'),
        ('Cyber Odyssey 2077 — обновление 2.0', 'Масштабный патч добавляет новый район города, систему транспорта и улучшенный ИИ. Бесплатно для всех владельцев.', 'https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg'),
        ('Mech Arena Online — новый сезон', 'Сезон «Железный шторм» уже доступен. Новый боевой пропуск, 3 меха и карта «Заброшенный завод».', 'https://cdn.cloudflare.steamstatic.com/steam/apps/1237970/header.jpg'),
        ('GameHub — что нового', 'Добавлены друзья, подарки, новости, скриншоты игр и система избранного в библиотеке. Спасибо за отзывы!', 'https://cdn.cloudflare.steamstatic.com/steam/apps/730/header.jpg'),
    ]
    for t, b, img in news_items:
        c.execute('INSERT INTO news (title, body, image_url) VALUES (?,?,?)', (t, b, img))
    conn.commit()


def seed_extra(conn):
    c = conn.cursor()
    # Achievements
    c.execute('SELECT COUNT(*) FROM achievements')
    if c.fetchone()[0] == 0:
        ach = [
            ('first_purchase', 'Первая покупка', 'Купите свою первую игру', 'fa-shopping-bag', 20),
            ('collector_5', 'Коллекционер', 'Соберите 5 игр в библиотеке', 'fa-book', 30),
            ('collector_10', 'Библиотека мечты', '10 игр в библиотеке', 'fa-book-open', 50),
            ('reviewer', 'Критик', 'Оставьте первый отзыв', 'fa-star', 15),
            ('social', 'Дружелюбный', 'Добавьте первого друга', 'fa-user-friends', 15),
            ('generous', 'Щедрый', 'Подарите игру другу', 'fa-gift', 25),
            ('wishlist', 'Мечтатель', 'Добавьте игру в желаемое', 'fa-heart', 10),
            ('gamer', 'Геймер', 'Наберите 60 минут игрового времени', 'fa-gamepad', 20),
            ('rich', 'Толстосум', 'Пополните баланс', 'fa-coins', 10),
            ('subscriber', 'Подписчик', 'Оформите GameHub Plus', 'fa-crown', 40),
        ]
        for a in ach:
            c.execute('INSERT INTO achievements (code, title, description, icon, points) VALUES (?,?,?,?,?)', a)

    # Promo codes
    c.execute('SELECT COUNT(*) FROM promo_codes')
    if c.fetchone()[0] == 0:
        for code, pct in [('GAMEHUB10', 10), ('STEAM20', 20), ('SALE30', 30), ('WELCOME15', 15)]:
            c.execute('INSERT INTO promo_codes (code, discount_percent, max_uses) VALUES (?,?,?)', (code, pct, 1000))

    # Collections
    c.execute('SELECT COUNT(*) FROM collections')
    if c.fetchone()[0] == 0:
        cols = [
            ('indie-hits', 'Инди-хиты', 'Лучшие независимые игры', ''),
            ('coop', 'Кооператив', 'Играйте вместе с друзьями', ''),
            ('bestsellers', 'Бестселлеры', 'Самые популярные игры', ''),
            ('free-to-play', 'Бесплатные', 'Играйте бесплатно', ''),
        ]
        for slug, title, desc, img in cols:
            c.execute('INSERT INTO collections (slug, title, description, image_url) VALUES (?,?,?,?)', (slug, title, desc, img))
        # link some games
        games = c.execute('SELECT id, price, tags, genre FROM games').fetchall()
        col_ids = {r[0]: r[1] for r in c.execute('SELECT slug, id FROM collections').fetchall()}
        for g in games:
            gid, price, tags, genre = g[0], g[1], (g[2] or ''), (g[3] or '')
            if price == 0 and 'free-to-play' in col_ids:
                c.execute('INSERT OR IGNORE INTO collection_games VALUES (?,?)', (col_ids['free-to-play'], gid))
            if 'Инди' in tags or 'Indie' in genre:
                if 'indie-hits' in col_ids:
                    c.execute('INSERT OR IGNORE INTO collection_games VALUES (?,?)', (col_ids['indie-hits'], gid))
            if 'Кооп' in tags or 'Co-op' in genre or 'Мультиплеер' in tags:
                if 'coop' in col_ids:
                    c.execute('INSERT OR IGNORE INTO collection_games VALUES (?,?)', (col_ids['coop'], gid))
            if 'bestsellers' in col_ids:
                c.execute('INSERT OR IGNORE INTO collection_games VALUES (?,?)', (col_ids['bestsellers'], gid))

    # Trailers for some games
    trailers = {
        'Cyber Odyssey 2077': 'https://www.youtube.com/embed/qIcTM8WXFjk',
        'Shadow Protocol': 'https://www.youtube.com/embed/w6bE11OpKn4',
        'Stellar Frontiers': 'https://www.youtube.com/embed/Ra_VTSFiO5A',
        'Pixel Legends': 'https://www.youtube.com/embed/Bnm8eJZBLLM',
        'Mech Arena Online': 'https://www.youtube.com/embed/dQw4w9WgXcQ',
        'Ocean Depths': 'https://www.youtube.com/embed/zbTYc4_5xX4',
    }
    for title, url in trailers.items():
        c.execute('UPDATE games SET trailer_url=? WHERE title=?', (url, title))

    # Sample guides
    c.execute('SELECT COUNT(*) FROM guides')
    if c.fetchone()[0] == 0:
        g = c.execute('SELECT id FROM games LIMIT 3').fetchall()
        if g:
            c.execute('INSERT INTO guides (game_id, user_id, title, body) VALUES (?,?,?,?)',
                      (g[0][0], 1, 'Гайд для новичков', 'Начните с сюжетной кампании. Не тратьте ресурсы впустую. Изучите карту и сохраняйтесь часто.'))
            if len(g) > 1:
                c.execute('INSERT INTO guides (game_id, user_id, title, body) VALUES (?,?,?,?)',
                          (g[1][0], 1, 'Оптимальная сборка', 'Для максимального DPS качайте ветку силы. Экипируйте артефакты с бонусом к криту.'))

    conn.commit()


def notify(user_id, title, body, link=''):
    try:
        conn = get_db()
        conn.execute('INSERT INTO notifications (user_id, title, body, link) VALUES (?,?,?,?)',
                     (user_id, title, body, link))
        conn.commit()
        conn.close()
    except Exception:
        pass


def unlock_achievement(user_id, code):
    try:
        conn = get_db()
        ach = conn.execute('SELECT id, title FROM achievements WHERE code=?', (code,)).fetchone()
        if not ach:
            conn.close()
            return
        try:
            conn.execute('INSERT INTO user_achievements (user_id, achievement_id) VALUES (?,?)',
                         (user_id, ach['id']))
            conn.commit()
            notify(user_id, 'Достижение разблокировано!', ach['title'], '/achievements')
        except Exception:
            pass
        conn.close()
    except Exception:
        pass


def check_achievements(user_id):
    conn = get_db()
    lib_count = conn.execute('SELECT COUNT(*) FROM library WHERE user_id=?', (user_id,)).fetchone()[0]
    rev_count = conn.execute('SELECT COUNT(*) FROM reviews WHERE user_id=?', (user_id,)).fetchone()[0]
    playtime = conn.execute('SELECT COALESCE(SUM(playtime),0) FROM library WHERE user_id=?', (user_id,)).fetchone()[0]
    conn.close()
    if lib_count >= 1:
        unlock_achievement(user_id, 'first_purchase')
    if lib_count >= 5:
        unlock_achievement(user_id, 'collector_5')
    if lib_count >= 10:
        unlock_achievement(user_id, 'collector_10')
    if rev_count >= 1:
        unlock_achievement(user_id, 'reviewer')
    if playtime >= 60:
        unlock_achievement(user_id, 'gamer')


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        user = get_current_user()
        if not user or not user['is_admin']:
            flash('Доступ только для администратора', 'error')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated


def log_activity(user_id, action, details=''):
    try:
        conn = get_db()
        conn.execute('INSERT INTO activity (user_id, action, details) VALUES (?,?,?)',
                     (user_id, action, details))
        conn.commit()
        conn.close()
    except Exception:
        pass

# ───────────────────────── helpers ─────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('Войдите в аккаунт, чтобы продолжить', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_current_user():
    if 'user_id' not in session:
        return None
    conn = get_db()
    user = conn.execute('SELECT * FROM users WHERE id = ?', (session['user_id'],)).fetchone()
    conn.close()
    return user

def get_final_price(game):
    if game['discount'] > 0:
        return round(game['price'] * (1 - game['discount'] / 100), 2)
    return game['price']

def track_recent(game_id):
    recent = session.get('recent', [])
    if game_id in recent:
        recent.remove(game_id)
    recent.insert(0, game_id)
    session['recent'] = recent[:10]

# ───────────────────────── routes ─────────────────────────

@app.route('/')
def index():
    conn = get_db()
    featured = conn.execute('SELECT * FROM games WHERE featured = 1 ORDER BY rating DESC LIMIT 8').fetchall()
    if not featured:
        featured = conn.execute('SELECT * FROM games ORDER BY rating DESC LIMIT 6').fetchall()
    specials = conn.execute('SELECT * FROM games WHERE discount > 0 ORDER BY discount DESC LIMIT 6').fetchall()
    new_releases = conn.execute('SELECT * FROM games ORDER BY release_date DESC LIMIT 6').fetchall()
    free = conn.execute('SELECT * FROM games WHERE price = 0').fetchall()
    top_rated = conn.execute('SELECT * FROM games ORDER BY rating DESC LIMIT 4').fetchall()
    news = conn.execute('SELECT * FROM news ORDER BY created_at DESC LIMIT 3').fetchall()
    conn.close()
    user = get_current_user()
    return render_template('index.html', featured=featured, specials=specials,
                           new_releases=new_releases, free=free, top_rated=top_rated,
                           news=news, user=user, get_final_price=get_final_price)

@app.route('/store')
def store():
    conn = get_db()
    query = request.args.get('q', '').strip()
    genre = request.args.get('genre', '')
    sort = request.args.get('sort', 'rating')
    max_price = request.args.get('max_price', type=float)
    only_discount = request.args.get('discount') == '1'
    free_only = request.args.get('free') == '1'

    sql = 'SELECT * FROM games WHERE 1=1'
    params = []
    if query:
        sql += ' AND (title LIKE ? OR tags LIKE ? OR developer LIKE ? OR genre LIKE ?)'
        params.extend([f'%{query}%'] * 4)
    if genre:
        sql += ' AND genre LIKE ?'
        params.append(f'%{genre}%')
    if max_price is not None:
        sql += ' AND price <= ?'
        params.append(max_price)
    if only_discount:
        sql += ' AND discount > 0'
    if free_only:
        sql += ' AND price = 0'

    if sort == 'price_asc':
        sql += ' ORDER BY CASE WHEN discount > 0 THEN price*(1-discount/100.0) ELSE price END ASC'
    elif sort == 'price_desc':
        sql += ' ORDER BY CASE WHEN discount > 0 THEN price*(1-discount/100.0) ELSE price END DESC'
    elif sort == 'name':
        sql += ' ORDER BY title ASC'
    elif sort == 'discount':
        sql += ' ORDER BY discount DESC'
    elif sort == 'date':
        sql += ' ORDER BY release_date DESC'
    else:
        sql += ' ORDER BY rating DESC'

    games = conn.execute(sql, params).fetchall()
    all_games = conn.execute('SELECT genre FROM games').fetchall()
    genres = set()
    for g in all_games:
        for part in g['genre'].split(','):
            genres.add(part.strip())
    conn.close()
    user = get_current_user()
    return render_template('store.html', games=games, user=user, query=query,
                           genre=genre, sort=sort, genres=sorted(genres),
                           max_price=max_price, only_discount=only_discount,
                           free_only=free_only, get_final_price=get_final_price)

@app.route('/game/<int:game_id>')
def game_detail(game_id):
    conn = get_db()
    game = conn.execute('SELECT * FROM games WHERE id = ?', (game_id,)).fetchone()
    if not game:
        flash('Игра не найдена', 'error')
        return redirect(url_for('store'))
    track_recent(game_id)

    reviews = conn.execute('''SELECT r.*, u.username, u.display_name, u.avatar
                              FROM reviews r JOIN users u ON r.user_id = u.id
                              WHERE r.game_id = ? ORDER BY r.created_at DESC LIMIT 30''',
                           (game_id,)).fetchall()

    in_library = in_wishlist = in_cart = False
    user_review = None
    playtime = 0
    user = get_current_user()
    if user:
        lib = conn.execute('SELECT playtime FROM library WHERE user_id = ? AND game_id = ?',
                           (user['id'], game_id)).fetchone()
        in_library = lib is not None
        if lib:
            playtime = lib['playtime']
        in_wishlist = conn.execute('SELECT 1 FROM wishlist WHERE user_id = ? AND game_id = ?',
                                   (user['id'], game_id)).fetchone() is not None
        in_cart = conn.execute('SELECT 1 FROM cart WHERE user_id = ? AND game_id = ?',
                               (user['id'], game_id)).fetchone() is not None
        user_review = conn.execute('SELECT * FROM reviews WHERE user_id = ? AND game_id = ?',
                                   (user['id'], game_id)).fetchone()

    similar = conn.execute('''SELECT * FROM games WHERE id != ? AND
                              (genre LIKE ? OR tags LIKE ?) LIMIT 4''',
                           (game_id, f"%{game['genre'].split(',')[0].strip()}%",
                            f"%{game['tags'].split(',')[0].strip()}%")).fetchall()

    screenshots = [s.strip() for s in (game['screenshots'] or '').split(',') if s.strip()]
    conn.close()
    return render_template('game_detail.html', game=game, reviews=reviews, user=user,
                           in_library=in_library, in_wishlist=in_wishlist, in_cart=in_cart,
                           user_review=user_review, similar=similar, screenshots=screenshots,
                           playtime=playtime, get_final_price=get_final_price)

@app.route('/news')
def news_list():
    conn = get_db()
    items = conn.execute('SELECT * FROM news ORDER BY created_at DESC').fetchall()
    conn.close()
    return render_template('news.html', news=items, user=get_current_user())

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm = request.form.get('confirm', '')
        if not username or not email or not password:
            flash('Заполните все поля', 'error')
            return render_template('register.html')
        if password != confirm:
            flash('Пароли не совпадают', 'error')
            return render_template('register.html')
        if len(password) < 6:
            flash('Пароль должен быть не менее 6 символов', 'error')
            return render_template('register.html')
        conn = get_db()
        try:
            hashed = generate_password_hash(password)
            c = conn.cursor()
            is_adm = 1 if username.lower() == 'admin' else 0
            c.execute('INSERT INTO users (username, email, password, display_name, is_admin) VALUES (?,?,?,?,?)',
                      (username, email, hashed, username, is_adm))
            conn.commit()
            user_id = c.lastrowid
            session['user_id'] = user_id
            session['username'] = username
            log_activity(user_id, 'register', 'Регистрация в GameHub')
            flash(f'Добро пожаловать, {username}! На ваш счёт зачислено 1000 ₽', 'success')
            return redirect(url_for('index'))
        except sqlite3.IntegrityError:
            flash('Имя пользователя или email уже заняты', 'error')
        finally:
            conn.close()
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        conn = get_db()
        user = conn.execute('SELECT * FROM users WHERE username = ? OR email = ?',
                            (username, username)).fetchone()
        conn.close()
        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            log_activity(user['id'], 'login', 'Вход в аккаунт')
            flash(f'С возвращением, {user["display_name"] or user["username"]}!', 'success')
            return redirect(url_for('index'))
        flash('Неверное имя пользователя или пароль', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Вы вышли из аккаунта', 'info')
    return redirect(url_for('index'))

@app.route('/profile')
@login_required
def profile():
    user = get_current_user()
    conn = get_db()
    library = conn.execute('''SELECT g.*, l.purchase_date, l.playtime, l.favorite
                              FROM library l JOIN games g ON l.game_id = g.id
                              WHERE l.user_id = ? ORDER BY l.favorite DESC, l.purchase_date DESC''',
                           (user['id'],)).fetchall()
    wishlist = conn.execute('''SELECT g.*, w.added_at FROM wishlist w
                               JOIN games g ON w.game_id = g.id WHERE w.user_id = ?
                               ORDER BY w.added_at DESC''', (user['id'],)).fetchall()
    reviews = conn.execute('''SELECT r.*, g.title, g.image_url FROM reviews r
                              JOIN games g ON r.game_id = g.id WHERE r.user_id = ?
                              ORDER BY r.created_at DESC''', (user['id'],)).fetchall()
    activities = conn.execute('''SELECT * FROM activity WHERE user_id = ?
                                 ORDER BY created_at DESC LIMIT 15''', (user['id'],)).fetchall()
    # friends
    friends = conn.execute('''SELECT u.id, u.username, u.display_name, u.avatar, f.status
                              FROM friends f JOIN users u ON
                              (CASE WHEN f.user_id = ? THEN f.friend_id ELSE f.user_id END) = u.id
                              WHERE (f.user_id = ? OR f.friend_id = ?) AND f.status = 'accepted' ''',
                           (user['id'], user['id'], user['id'])).fetchall()
    pending = conn.execute('''SELECT f.id as req_id, u.id, u.username, u.display_name, u.avatar
                              FROM friends f JOIN users u ON f.user_id = u.id
                              WHERE f.friend_id = ? AND f.status = 'pending' ''',
                           (user['id'],)).fetchall()
    gifts = conn.execute('''SELECT g.*, games.title, games.image_url, u.username as from_name
                            FROM gifts g JOIN games ON g.game_id = games.id
                            JOIN users u ON g.from_user = u.id
                            WHERE g.to_user = ? AND g.status = 'pending' ''',
                         (user['id'],)).fetchall()
    conn.close()
    return render_template('profile.html', user=user, library=library, wishlist=wishlist,
                           reviews=reviews, activities=activities, friends=friends,
                           pending=pending, gifts=gifts, get_final_price=get_final_price)

@app.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    user = get_current_user()
    if request.method == 'POST':
        display_name = request.form.get('display_name', '').strip()
        bio = request.form.get('bio', '').strip()
        conn = get_db()
        avatar_path = user['avatar']
        if 'avatar' in request.files:
            file = request.files['avatar']
            if file and file.filename and allowed_file(file.filename):
                filename = secure_filename(f"user_{user['id']}_{file.filename}")
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                avatar_path = f'/static/uploads/{filename}'
        avatar_url = request.form.get('avatar_url', '').strip()
        if avatar_url and avatar_url.startswith('http'):
            avatar_path = avatar_url
        conn.execute('UPDATE users SET display_name=?, bio=?, avatar=? WHERE id=?',
                     (display_name or user['username'], bio, avatar_path, user['id']))
        conn.commit()
        conn.close()
        log_activity(user['id'], 'profile_edit', 'Обновлён профиль')
        flash('Профиль обновлён!', 'success')
        return redirect(url_for('profile'))
    return render_template('edit_profile.html', user=user)

@app.route('/profile/password', methods=['GET', 'POST'])
@login_required
def change_password():
    user = get_current_user()
    if request.method == 'POST':
        old = request.form.get('old_password', '')
        new = request.form.get('new_password', '')
        confirm = request.form.get('confirm', '')
        if not check_password_hash(user['password'], old):
            flash('Неверный текущий пароль', 'error')
        elif new != confirm:
            flash('Новые пароли не совпадают', 'error')
        elif len(new) < 6:
            flash('Пароль должен быть не менее 6 символов', 'error')
        else:
            conn = get_db()
            conn.execute('UPDATE users SET password=? WHERE id=?',
                         (generate_password_hash(new), user['id']))
            conn.commit()
            conn.close()
            flash('Пароль изменён', 'success')
            return redirect(url_for('profile'))
    return render_template('change_password.html', user=user)

@app.route('/cart')
@login_required
def cart():
    user = get_current_user()
    conn = get_db()
    items = conn.execute('''SELECT g.*, c.id as cart_id FROM cart c
                            JOIN games g ON c.game_id = g.id WHERE c.user_id = ?''',
                         (user['id'],)).fetchall()
    conn.close()
    total = sum(get_final_price(item) for item in items)
    promo_discount = session.get('promo_discount', 0)
    promo_code = session.get('promo_code', '')
    if promo_discount:
        total = round(total * (1 - promo_discount / 100), 2)
    return render_template('cart.html', items=items, total=total, user=user,
                           get_final_price=get_final_price, promo_code=promo_code,
                           promo_discount=promo_discount)

@app.route('/cart/add/<int:game_id>')
@login_required
def add_to_cart(game_id):
    user = get_current_user()
    conn = get_db()
    if conn.execute('SELECT 1 FROM library WHERE user_id=? AND game_id=?',
                    (user['id'], game_id)).fetchone():
        flash('Эта игра уже у вас в библиотеке', 'info')
        conn.close()
        return redirect(url_for('game_detail', game_id=game_id))
    try:
        conn.execute('INSERT INTO cart (user_id, game_id) VALUES (?,?)', (user['id'], game_id))
        conn.commit()
        flash('Игра добавлена в корзину', 'success')
    except sqlite3.IntegrityError:
        flash('Игра уже в корзине', 'info')
    conn.close()
    return redirect(request.referrer or url_for('store'))

@app.route('/cart/remove/<int:game_id>')
@login_required
def remove_from_cart(game_id):
    conn = get_db()
    conn.execute('DELETE FROM cart WHERE user_id=? AND game_id=?', (session['user_id'], game_id))
    conn.commit()
    conn.close()
    flash('Игра удалена из корзины', 'info')
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['POST'])
@login_required
def checkout():
    user = get_current_user()
    conn = get_db()
    items = conn.execute('''SELECT g.* FROM cart c JOIN games g ON c.game_id = g.id
                            WHERE c.user_id = ?''', (user['id'],)).fetchall()
    if not items:
        flash('Корзина пуста', 'warning')
        conn.close()
        return redirect(url_for('cart'))
    total = sum(get_final_price(item) for item in items)
    promo_discount = session.get('promo_discount', 0)
    if promo_discount:
        total = round(total * (1 - promo_discount / 100), 2)
    if user['balance'] < total:
        flash(f'Недостаточно средств. Нужно {total:.0f} ₽, у вас {user["balance"]:.0f} ₽', 'error')
        conn.close()
        return redirect(url_for('cart'))
    titles = []
    for item in items:
        conn.execute('INSERT OR IGNORE INTO library (user_id, game_id) VALUES (?,?)',
                     (user['id'], item['id']))
        conn.execute('DELETE FROM wishlist WHERE user_id=? AND game_id=?', (user['id'], item['id']))
        titles.append(item['title'])
    conn.execute('UPDATE users SET balance = balance - ? WHERE id = ?', (total, user['id']))
    conn.execute('DELETE FROM cart WHERE user_id = ?', (user['id'],))
    conn.commit()
    conn.close()
    log_activity(user['id'], 'purchase', f'Куплено: {", ".join(titles)} за {total:.0f} ₽')
    flash(f'Покупка успешна! Списано {total:.0f} ₽. Игры добавлены в библиотеку.', 'success')
    return redirect(url_for('profile'))

@app.route('/wishlist/add/<int:game_id>')
@login_required
def add_to_wishlist(game_id):
    user = get_current_user()
    conn = get_db()
    if conn.execute('SELECT 1 FROM library WHERE user_id=? AND game_id=?',
                    (user['id'], game_id)).fetchone():
        flash('Игра уже в библиотеке', 'info')
        conn.close()
        return redirect(url_for('game_detail', game_id=game_id))
    try:
        conn.execute('INSERT INTO wishlist (user_id, game_id) VALUES (?,?)', (user['id'], game_id))
        conn.commit()
        flash('Добавлено в список желаемого', 'success')
    except sqlite3.IntegrityError:
        flash('Уже в списке желаемого', 'info')
    conn.close()
    return redirect(request.referrer or url_for('game_detail', game_id=game_id))

@app.route('/wishlist/remove/<int:game_id>')
@login_required
def remove_from_wishlist(game_id):
    conn = get_db()
    conn.execute('DELETE FROM wishlist WHERE user_id=? AND game_id=?', (session['user_id'], game_id))
    conn.commit()
    conn.close()
    flash('Удалено из списка желаемого', 'info')
    return redirect(request.referrer or url_for('profile'))

@app.route('/review/<int:game_id>', methods=['POST'])
@login_required
def add_review(game_id):
    user = get_current_user()
    rating = request.form.get('rating', type=int)
    text = request.form.get('text', '').strip()
    if not rating or rating < 1 or rating > 5:
        flash('Выберите оценку от 1 до 5', 'error')
        return redirect(url_for('game_detail', game_id=game_id))
    conn = get_db()
    if not conn.execute('SELECT 1 FROM library WHERE user_id=? AND game_id=?',
                        (user['id'], game_id)).fetchone():
        flash('Сначала купите игру, чтобы оставить отзыв', 'warning')
        conn.close()
        return redirect(url_for('game_detail', game_id=game_id))
    existing = conn.execute('SELECT id FROM reviews WHERE user_id=? AND game_id=?',
                            (user['id'], game_id)).fetchone()
    if existing:
        conn.execute('UPDATE reviews SET rating=?, text=?, created_at=CURRENT_TIMESTAMP WHERE id=?',
                     (rating, text, existing['id']))
        flash('Отзыв обновлён', 'success')
    else:
        conn.execute('INSERT INTO reviews (user_id, game_id, rating, text) VALUES (?,?,?,?)',
                     (user['id'], game_id, rating, text))
        flash('Отзыв добавлен!', 'success')
    avg = conn.execute('SELECT AVG(rating), COUNT(*) FROM reviews WHERE game_id=?',
                       (game_id,)).fetchone()
    if avg[0]:
        conn.execute('UPDATE games SET rating=?, reviews_count=? WHERE id=?',
                     (round(avg[0], 1), avg[1], game_id))
    conn.commit()
    conn.close()
    log_activity(user['id'], 'review', f'Отзыв на игру #{game_id}: {rating}★')
    return redirect(url_for('game_detail', game_id=game_id))

@app.route('/library')
@login_required
def library():
    user = get_current_user()
    sort = request.args.get('sort', 'date')
    conn = get_db()
    order = {'name': 'g.title ASC', 'playtime': 'l.playtime DESC',
             'favorite': 'l.favorite DESC, g.title ASC'}.get(sort, 'l.purchase_date DESC')
    games = conn.execute(f'''SELECT g.*, l.purchase_date, l.playtime, l.favorite
                             FROM library l JOIN games g ON l.game_id = g.id
                             WHERE l.user_id = ? ORDER BY {order}''', (user['id'],)).fetchall()
    conn.close()
    return render_template('library.html', games=games, user=user, sort=sort)

@app.route('/play/<int:game_id>')
@login_required
def play_game(game_id):
    """Simulate playing — add random playtime minutes."""
    user = get_current_user()
    conn = get_db()
    lib = conn.execute('SELECT id, playtime FROM library WHERE user_id=? AND game_id=?',
                       (user['id'], game_id)).fetchone()
    if not lib:
        flash('Игра не в библиотеке', 'error')
        conn.close()
        return redirect(url_for('store'))
    minutes = random.randint(15, 120)
    conn.execute('UPDATE library SET playtime = playtime + ? WHERE id = ?', (minutes, lib['id']))
    game = conn.execute('SELECT title FROM games WHERE id=?', (game_id,)).fetchone()
    conn.commit()
    conn.close()
    log_activity(user['id'], 'play', f'{game["title"]}: +{minutes} мин.')
    flash(f'Вы поиграли в «{game["title"]}» — +{minutes} мин. игрового времени!', 'success')
    return redirect(request.referrer or url_for('library'))

@app.route('/favorite/<int:game_id>')
@login_required
def toggle_favorite(game_id):
    conn = get_db()
    lib = conn.execute('SELECT id, favorite FROM library WHERE user_id=? AND game_id=?',
                       (session['user_id'], game_id)).fetchone()
    if lib:
        new_val = 0 if lib['favorite'] else 1
        conn.execute('UPDATE library SET favorite=? WHERE id=?', (new_val, lib['id']))
        conn.commit()
        flash('Добавлено в избранное' if new_val else 'Убрано из избранного', 'success')
    conn.close()
    return redirect(request.referrer or url_for('library'))

@app.route('/add_funds', methods=['POST'])
@login_required
def add_funds():
    amount = request.form.get('amount', type=float)
    if not amount or amount <= 0 or amount > 10000:
        flash('Сумма должна быть от 1 до 10000 ₽', 'error')
        return redirect(url_for('profile'))
    conn = get_db()
    conn.execute('UPDATE users SET balance = balance + ? WHERE id = ?', (amount, session['user_id']))
    conn.commit()
    conn.close()
    log_activity(session['user_id'], 'funds', f'Пополнение +{amount:.0f} ₽')
    flash(f'Баланс пополнен на {amount:.0f} ₽', 'success')
    return redirect(url_for('profile'))

# ─── Friends ───

@app.route('/friends/add', methods=['POST'])
@login_required
def add_friend():
    username = request.form.get('username', '').strip()
    if not username:
        flash('Введите имя пользователя', 'error')
        return redirect(url_for('profile'))
    conn = get_db()
    target = conn.execute('SELECT id, username FROM users WHERE username = ?', (username,)).fetchone()
    if not target:
        flash('Пользователь не найден', 'error')
        conn.close()
        return redirect(url_for('profile'))
    if target['id'] == session['user_id']:
        flash('Нельзя добавить себя', 'error')
        conn.close()
        return redirect(url_for('profile'))
    existing = conn.execute('''SELECT id FROM friends WHERE
        (user_id=? AND friend_id=?) OR (user_id=? AND friend_id=?)''',
        (session['user_id'], target['id'], target['id'], session['user_id'])).fetchone()
    if existing:
        flash('Запрос уже отправлен или вы уже друзья', 'info')
        conn.close()
        return redirect(url_for('profile'))
    conn.execute('INSERT INTO friends (user_id, friend_id, status) VALUES (?,?,?)',
                 (session['user_id'], target['id'], 'pending'))
    conn.commit()
    conn.close()
    flash(f'Запрос в друзья отправлен пользователю {username}', 'success')
    return redirect(url_for('profile'))

@app.route('/friends/accept/<int:req_id>')
@login_required
def accept_friend(req_id):
    conn = get_db()
    conn.execute('UPDATE friends SET status=? WHERE id=? AND friend_id=?',
                 ('accepted', req_id, session['user_id']))
    conn.commit()
    conn.close()
    flash('Запрос принят', 'success')
    return redirect(url_for('profile'))

@app.route('/friends/decline/<int:req_id>')
@login_required
def decline_friend(req_id):
    conn = get_db()
    conn.execute('DELETE FROM friends WHERE id=? AND friend_id=?', (req_id, session['user_id']))
    conn.commit()
    conn.close()
    flash('Запрос отклонён', 'info')
    return redirect(url_for('profile'))

# ─── Gifts ───

@app.route('/gift/<int:game_id>', methods=['GET', 'POST'])
@login_required
def gift_game(game_id):
    user = get_current_user()
    conn = get_db()
    game = conn.execute('SELECT * FROM games WHERE id=?', (game_id,)).fetchone()
    if not game:
        flash('Игра не найдена', 'error')
        conn.close()
        return redirect(url_for('store'))
    price = get_final_price(game)
    if request.method == 'POST':
        to_username = request.form.get('username', '').strip()
        message = request.form.get('message', '').strip()
        target = conn.execute('SELECT id FROM users WHERE username=?', (to_username,)).fetchone()
        if not target:
            flash('Пользователь не найден', 'error')
            conn.close()
            return render_template('gift.html', game=game, user=user, price=price)
        if target['id'] == user['id']:
            flash('Нельзя подарить себе', 'error')
            conn.close()
            return render_template('gift.html', game=game, user=user, price=price)
        if conn.execute('SELECT 1 FROM library WHERE user_id=? AND game_id=?',
                        (target['id'], game_id)).fetchone():
            flash('У этого пользователя уже есть эта игра', 'error')
            conn.close()
            return render_template('gift.html', game=game, user=user, price=price)
        if user['balance'] < price:
            flash('Недостаточно средств', 'error')
            conn.close()
            return render_template('gift.html', game=game, user=user, price=price)
        conn.execute('UPDATE users SET balance = balance - ? WHERE id=?', (price, user['id']))
        conn.execute('INSERT INTO gifts (from_user, to_user, game_id, message) VALUES (?,?,?,?)',
                     (user['id'], target['id'], game_id, message))
        conn.commit()
        conn.close()
        log_activity(user['id'], 'gift', f'Подарок «{game["title"]}» → {to_username}')
        flash(f'Подарок «{game["title"]}» отправлен пользователю {to_username}!', 'success')
        return redirect(url_for('store'))
    conn.close()
    return render_template('gift.html', game=game, user=user, price=price)

@app.route('/gift/accept/<int:gift_id>')
@login_required
def accept_gift(gift_id):
    conn = get_db()
    gift = conn.execute('SELECT * FROM gifts WHERE id=? AND to_user=? AND status=?',
                        (gift_id, session['user_id'], 'pending')).fetchone()
    if gift:
        conn.execute('INSERT OR IGNORE INTO library (user_id, game_id) VALUES (?,?)',
                     (session['user_id'], gift['game_id']))
        conn.execute('UPDATE gifts SET status=? WHERE id=?', ('accepted', gift_id))
        conn.commit()
        flash('Подарок принят! Игра добавлена в библиотеку.', 'success')
    conn.close()
    return redirect(url_for('profile'))

@app.route('/gift/decline/<int:gift_id>')
@login_required
def decline_gift(gift_id):
    conn = get_db()
    gift = conn.execute('SELECT * FROM gifts WHERE id=? AND to_user=? AND status=?',
                        (gift_id, session['user_id'], 'pending')).fetchone()
    if gift:
        # refund sender
        game = conn.execute('SELECT price, discount FROM games WHERE id=?', (gift['game_id'],)).fetchone()
        if game:
            price = get_final_price(game)
            conn.execute('UPDATE users SET balance = balance + ? WHERE id=?', (price, gift['from_user']))
        conn.execute('UPDATE gifts SET status=? WHERE id=?', ('declined', gift_id))
        conn.commit()
        flash('Подарок отклонён, средства возвращены отправителю', 'info')
    conn.close()
    return redirect(url_for('profile'))

@app.route('/user/<username>')
def public_profile(username):
    conn = get_db()
    profile_user = conn.execute('SELECT * FROM users WHERE username=?', (username,)).fetchone()
    if not profile_user:
        flash('Пользователь не найден', 'error')
        conn.close()
        return redirect(url_for('index'))
    library = conn.execute('''SELECT g.* FROM library l JOIN games g ON l.game_id = g.id
                              WHERE l.user_id = ? ORDER BY l.purchase_date DESC LIMIT 12''',
                           (profile_user['id'],)).fetchall()
    reviews = conn.execute('''SELECT r.*, g.title FROM reviews r JOIN games g ON r.game_id = g.id
                              WHERE r.user_id = ? ORDER BY r.created_at DESC LIMIT 5''',
                           (profile_user['id'],)).fetchall()
    conn.close()
    return render_template('public_profile.html', profile_user=profile_user,
                           library=library, reviews=reviews, user=get_current_user())

@app.route('/api/search')
def api_search():
    q = request.args.get('q', '').strip()
    if len(q) < 2:
        return jsonify([])
    conn = get_db()
    games = conn.execute('''SELECT id, title, image_url, price, discount FROM games
                            WHERE title LIKE ? LIMIT 8''', (f'%{q}%',)).fetchall()
    conn.close()
    return jsonify([{
        'id': g['id'], 'title': g['title'], 'image': g['image_url'],
        'price': get_final_price(g), 'discount': g['discount']
    } for g in games])

@app.route('/recent')
def recent_games():
    ids = session.get('recent', [])
    games = []
    if ids:
        conn = get_db()
        placeholders = ','.join('?' * len(ids))
        rows = conn.execute(f'SELECT * FROM games WHERE id IN ({placeholders})', ids).fetchall()
        # preserve order
        by_id = {r['id']: r for r in rows}
        games = [by_id[i] for i in ids if i in by_id]
        conn.close()
    return render_template('recent.html', games=games, user=get_current_user(),
                           get_final_price=get_final_price)


@app.route('/settings')
def settings():
    return render_template('settings.html', user=get_current_user())



@app.context_processor
def inject_globals():
    def _specials():
        try:
            conn = get_db()
            rows = conn.execute("SELECT * FROM games WHERE discount > 0 ORDER BY discount DESC LIMIT 5").fetchall()
            conn.close()
            return rows
        except Exception:
            return []
    return {"specials_global": _specials, "get_final_price": get_final_price}


# Register extra feature routes
try:
    from extra_routes import register_extra_routes
    register_extra_routes(app, {
        'get_db': get_db,
        'get_current_user': get_current_user,
        'login_required': login_required,
        'admin_required': admin_required,
        'get_final_price': get_final_price,
        'unlock_achievement': unlock_achievement,
        'check_achievements': check_achievements,
        'notify': notify,
    })
except Exception as _e:
    print('extra_routes load warning:', _e)


if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
