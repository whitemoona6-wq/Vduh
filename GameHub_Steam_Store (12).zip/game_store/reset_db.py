# -*- coding: utf-8 -*-
"""Reset database: delete and recreate with all games.
Run:  python reset_db.py
"""
import os
import sqlite3
import sys

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'game_store.db')

print('Database file:', DB)
if os.path.exists(DB):
    os.remove(DB)
    print('Old database deleted.')

# Import app after delete so init runs fresh
sys.path.insert(0, BASE)
try:
    import app
    print('Done. Games:', end=' ')
    conn = sqlite3.connect(DB)
    print(conn.execute('SELECT COUNT(*) FROM games').fetchone()[0])
    print('Titles:', [r[0] for r in conn.execute('SELECT title FROM games LIMIT 5')])
    conn.close()
except Exception as e:
    print('Error importing app:', e)
    print('Trying manual create...')
    # Minimal manual path
    from app import init_db, DATABASE
    init_db()
