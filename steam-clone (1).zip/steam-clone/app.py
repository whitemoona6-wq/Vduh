#!/usr/bin/env python3
"""
Grok Games — простой Flask-сервер для веб-приложения в стиле Steam.
Запуск: python app.py
Сайт будет доступен по адресу http://127.0.0.1:5000
"""

from flask import Flask, send_from_directory, jsonify, request
import os
import json

app = Flask(__name__, static_folder=".", static_url_path="")

# Путь к директории со статикой
BASE_DIR = os.path.dirname(os.path.abspath(__file__))


@app.route("/")
def index():
    """Главная страница"""
    return send_from_directory(BASE_DIR, "index.html")


@app.route("/<path:path>")
def static_files(path):
    """Раздача CSS, JS и других статических файлов"""
    return send_from_directory(BASE_DIR, path)


# --- Простой API (опционально, для будущего расширения) ---

@app.route("/api/health")
def health():
    """Проверка, что сервер жив"""
    return jsonify({"status": "ok", "app": "Grok Games", "version": "1.0"})


@app.route("/api/games")
def get_games():
    """
    Заглушка API списка игр.
    В демо-версии данные живут на клиенте (app.js),
    этот эндпоинт можно использовать для будущего бэкенда.
    """
    return jsonify({
        "message": "Данные игр находятся на клиенте (app.js). "
                   "Этот эндпоинт готов к расширению.",
        "count": 16
    })


if __name__ == "__main__":
    print("=" * 50)
    print("  🎮  Grok Games — сервер запущен")
    print("  Открой в браузере: http://127.0.0.1:5000")
    print("  Для остановки: Ctrl+C")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5000, debug=True)
