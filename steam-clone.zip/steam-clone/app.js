// ==================== DATA ====================
const GAMES = [
  {
    id: 1,
    title: "Cyberpunk 2077",
    genre: "RPG",
    price: 2999,
    discount: 50,
    rating: 4.6,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/header.jpg",
    desc: "Cyberpunk 2077 — приключенческая ролевая игра, действие которой происходит в мегаполисе Найт-Сити, где власть, гламур и модификации тела ценятся превыше всего.",
    tags: ["Открытый мир", "RPG", "Киберпанк"],
    screenshots: [
      "https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/ss_4bb6204d8dcd53e16088cdac761483a74ef93936.600x338.jpg",
      "https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/ss_b2960b4a5b0c4e7e8f0c0e0e0e0e0e0e0e0e0e0e.600x338.jpg",
      "https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/ss_b85337f1c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5.600x338.jpg"
    ],
    release: "2020",
    developer: "CD PROJEKT RED",
    isNew: false,
    isTop: true
  },
  {
    id: 2,
    title: "Elden Ring",
    genre: "RPG",
    price: 3499,
    discount: 30,
    rating: 4.8,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/header.jpg",
    desc: "НОВЫЙ ФЭНТЕЗИЙНЫЙ ЭКШН-RPG. Восстаньте, Тусклый, и будьте ведом благодатью, чтобы облечь власть Кольца Элден и стать Повелителем Элден.",
    tags: ["Souls-like", "Открытый мир", "Сложная"],
    screenshots: [
      "https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/ss_3e6960ab73be261228b54bf1b79ef110ab1e240f.600x338.jpg",
      "https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/ss_d8d1f5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5c5.600x338.jpg"
    ],
    release: "2022",
    developer: "FromSoftware",
    isNew: false,
    isTop: true
  },
  {
    id: 3,
    title: "Counter-Strike 2",
    genre: "Экшен",
    price: 0,
    discount: 0,
    rating: 4.5,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/730/header.jpg",
    desc: "Более 20 лет спустя Counter-Strike предлагает обновлённый опыт соревновательной игры. CS2 построен на движке Source 2.",
    tags: ["Шутер", "Мультиплеер", "Соревновательный"],
    screenshots: [],
    release: "2023",
    developer: "Valve",
    isNew: true,
    isTop: true
  },
  {
    id: 4,
    title: "Hades II",
    genre: "Инди",
    price: 1899,
    discount: 0,
    rating: 4.9,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1145350/header.jpg",
    desc: "Битва за Олимп продолжается в Hades II — долгожданном продолжении культовой roguelike-игры от Supergiant Games.",
    tags: ["Roguelike", "Экшен", "Мифология"],
    screenshots: [],
    release: "2024",
    developer: "Supergiant Games",
    isNew: true,
    isTop: true
  },
  {
    id: 5,
    title: "Stardew Valley",
    genre: "Симулятор",
    price: 499,
    discount: 20,
    rating: 4.9,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/413150/header.jpg",
    desc: "Вы унаследовали заброшенную ферму. Вооружившись подержанными инструментами и несколькими монетами, начинаете новую жизнь в Stardew Valley.",
    tags: ["Ферма", "Пиксель-арт", "Релакс"],
    screenshots: [],
    release: "2016",
    developer: "ConcernedApe",
    isNew: false,
    isTop: true
  },
  {
    id: 6,
    title: "Baldur's Gate 3",
    genre: "RPG",
    price: 3999,
    discount: 15,
    rating: 4.9,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1086940/header.jpg",
    desc: "Соберите отряд и возвращайтесь в Забытые Королевства в истории о дружбе, предательстве, жертве и абсолютной власти.",
    tags: ["CRPG", "Пошаговая", "D&D"],
    screenshots: [],
    release: "2023",
    developer: "Larian Studios",
    isNew: false,
    isTop: true
  },
  {
    id: 7,
    title: "The Witcher 3",
    genre: "RPG",
    price: 1199,
    discount: 70,
    rating: 4.9,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/292030/header.jpg",
    desc: "Вы — Геральт из Ривии, наёмник-охотник на чудовищ. Перед вами стоит выбор: найти девочку, которая является живым оружием массового поражения.",
    tags: ["Открытый мир", "Фэнтези", "Сюжет"],
    screenshots: [],
    release: "2015",
    developer: "CD PROJEKT RED",
    isNew: false,
    isTop: true
  },
  {
    id: 8,
    title: "Hollow Knight",
    genre: "Инди",
    price: 599,
    discount: 0,
    rating: 4.8,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/367520/header.jpg",
    desc: "Вы исследуете огромный подземный мир, полный насекомых и героев. Встречайте странных персонажей, сражайтесь с эпическими боссами.",
    tags: ["Метроидвания", "Сложная", "Атмосфера"],
    screenshots: [],
    release: "2017",
    developer: "Team Cherry",
    isNew: false,
    isTop: false
  },
  {
    id: 9,
    title: "Red Dead Redemption 2",
    genre: "Приключения",
    price: 2999,
    discount: 40,
    rating: 4.7,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/header.jpg",
    desc: "Америка, 1899 год. Артур Морган и банда Ван дер Линде вынуждены бежать. Наступает эпоха беззакония.",
    tags: ["Открытый мир", "Вестерн", "Сюжет"],
    screenshots: [],
    release: "2019",
    developer: "Rockstar Games",
    isNew: false,
    isTop: true
  },
  {
    id: 10,
    title: "Phasmophobia",
    genre: "Хоррор",
    price: 799,
    discount: 0,
    rating: 4.4,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/739630/header.jpg",
    desc: "Кооперативный хоррор о призраках. Работайте вместе, чтобы собрать доказательства паранормальной активности.",
    tags: ["Кооп", "Хоррор", "VR"],
    screenshots: [],
    release: "2020",
    developer: "Kinetic Games",
    isNew: false,
    isTop: false
  },
  {
    id: 11,
    title: "Civilization VI",
    genre: "Стратегия",
    price: 1999,
    discount: 60,
    rating: 4.5,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/289070/header.jpg",
    desc: "Создайте империю, которая выдержит испытание временем. Станьте лидером одной из цивилизаций мира.",
    tags: ["4X", "Пошаговая", "Глобальная"],
    screenshots: [],
    release: "2016",
    developer: "Firaxis Games",
    isNew: false,
    isTop: false
  },
  {
    id: 12,
    title: "Among Us",
    genre: "Инди",
    price: 0,
    discount: 0,
    rating: 4.2,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/945360/header.jpg",
    desc: "Онлайн-игра о командной работе и предательстве для 4–15 игроков. Выполняйте задания или саботируйте!",
    tags: ["Мультиплеер", "Социальная", "Предатель"],
    screenshots: [],
    release: "2018",
    developer: "Innersloth",
    isNew: false,
    isTop: false
  },
  {
    id: 13,
    title: "Terraria",
    genre: "Приключения",
    price: 399,
    discount: 0,
    rating: 4.8,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/105600/header.jpg",
    desc: "Копайте, сражайтесь, исследуйте, стройте! Нет ничего невозможного в этой насыщенной событиями приключенческой игре.",
    tags: ["Песочница", "Крафт", "2D"],
    screenshots: [],
    release: "2011",
    developer: "Re-Logic",
    isNew: false,
    isTop: false
  },
  {
    id: 14,
    title: "Dead by Daylight",
    genre: "Хоррор",
    price: 999,
    discount: 50,
    rating: 4.1,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/381210/header.jpg",
    desc: "Асимметричный хоррор-мультиплеер. Четверо выживших противостоят одному убийце.",
    tags: ["Асимметрия", "Хоррор", "Мультиплеер"],
    screenshots: [],
    release: "2016",
    developer: "Behaviour Interactive",
    isNew: false,
    isTop: false
  },
  {
    id: 15,
    title: "No Man's Sky",
    genre: "Приключения",
    price: 2499,
    discount: 35,
    rating: 4.3,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/275850/header.jpg",
    desc: "Исследуйте бесконечную вселенную. Откройте для себя неизвестные планеты, странных существ и древние цивилизации.",
    tags: ["Выживание", "Исследование", "Космос"],
    screenshots: [],
    release: "2016",
    developer: "Hello Games",
    isNew: false,
    isTop: false
  },
  {
    id: 16,
    title: "Dota 2",
    genre: "Стратегия",
    price: 0,
    discount: 0,
    rating: 4.3,
    image: "https://cdn.cloudflare.steamstatic.com/steam/apps/570/header.jpg",
    desc: "Ежедневная борьба за Древних. Выберите из сотни героев и уничтожьте базу противника.",
    tags: ["MOBA", "Мультиплеер", "Бесплатная"],
    screenshots: [],
    release: "2013",
    developer: "Valve",
    isNew: false,
    isTop: true
  }
];

const NEWS = [
  { title: "Большая летняя распродажа началась!", text: "Скидки до 90% на тысячи игр. Не пропустите!", date: "9 окт 2026" },
  { title: "Hades II выходит из раннего доступа", text: "Supergiant Games объявили дату релиза полной версии.", date: "7 окт 2026" },
  { title: "Новое обновление Cyberpunk 2077", text: "Патч 2.2 добавляет новые квесты и улучшения производительности.", date: "5 окт 2026" },
  { title: "Grok Games Awards 2026", text: "Голосуйте за лучшие игры года! Номинации открыты.", date: "1 окт 2026" },
  { title: "Бесплатные выходные: Baldur's Gate 3", text: "Попробуйте игру бесплатно до понедельника.", date: "28 сен 2026" }
];

const FRIENDS = [
  { name: "NightOwl", status: "В игре: Elden Ring", seed: "owl" },
  { name: "PixelMaster", status: "Онлайн", seed: "pixel" },
  { name: "CyberRonin", status: "В игре: Cyberpunk 2077", seed: "cyber" },
  { name: "FarmGirl", status: "В игре: Stardew Valley", seed: "farm" },
  { name: "DarkSoulsFan", status: "Не беспокоить", seed: "souls" },
  { name: "StrategyKing", status: "Онлайн", seed: "king" }
];

const REVIEWS = [
  { author: "ProGamer99", rating: "★★★★★", text: "Лучшая RPG, в которую я когда-либо играл. Сюжет, персонажи, мир — всё на высшем уровне!", game: "Baldur's Gate 3" },
  { author: "IndieLover", rating: "★★★★★", text: "Hades II даже лучше первой части. Геймплей отточен до совершенства.", game: "Hades II" },
  { author: "CasualPlayer", rating: "★★★★☆", text: "Отличная игра для расслабления после работы. Уже 200 часов на ферме!", game: "Stardew Valley" },
  { author: "HardcoreFan", rating: "★★★★★", text: "FromSoftware снова доказали, что они мастера. Боссы невероятные.", game: "Elden Ring" }
];

const ACHIEVEMENTS = [
  { icon: "🏆", title: "Первая покупка", desc: "Купите свою первую игру" },
  { icon: "⭐", title: "Коллекционер", desc: "Соберите 5 игр в библиотеке" },
  { icon: "🔥", title: "Горячая распродажа", desc: "Купите игру со скидкой 50%+" },
  { icon: "💎", title: "VIP", desc: "Потратьте более 5000 ₽" },
  { icon: "🎮", title: "Игроман", desc: "Имейте 10 игр в библиотеке" },
  { icon: "❤️", title: "Мечтатель", desc: "Добавьте 5 игр в желаемое" },
  { icon: "🌙", title: "Ночная сова", desc: "Зайдите в магазин после полуночи" },
  { icon: "🚀", title: "Ранний доступ", desc: "Купите новинку" }
];

// ==================== STATE ====================
let cart = JSON.parse(localStorage.getItem('gg_cart') || '[]');
let library = JSON.parse(localStorage.getItem('gg_library') || '[]');
let wishlist = JSON.parse(localStorage.getItem('gg_wishlist') || '[]');
let profile = JSON.parse(localStorage.getItem('gg_profile') || JSON.stringify({
  name: 'Игрок',
  status: 'Онлайн',
  bio: 'Добро пожаловать в мой профиль!',
  avatarSeed: 'Player',
  themeColor: '#1b2838',
  banner: 'default'
}));

let currentCategory = 'all';
let libFilter = 'all';
let selectedThemeColor = profile.themeColor;

// ==================== INIT ====================
document.addEventListener('DOMContentLoaded', () => {
  applyProfile();
  renderGames();
  renderNews();
  renderFriends();
  renderReviews();
  updateCartUI();
  updateLibraryUI();
  updateWishlistUI();
  setupNav();
  setupProfileTabs();
  setupColorPicker();
  setupAvatarPreview();
  rotateHero();
  setInterval(rotateHero, 8000);
});

// ==================== NAVIGATION ====================
function setupNav() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const page = btn.dataset.page;
      showPage(page);
    });
  });
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  const page = document.getElementById('page-' + pageId);
  if (page) page.classList.add('active');
  const btn = document.querySelector(`.nav-btn[data-page="${pageId}"]`);
  if (btn) btn.classList.add('active');

  if (pageId === 'library') updateLibraryUI();
  if (pageId === 'wishlist') updateWishlistUI();
  if (pageId === 'profile') updateProfileStats();
}

// ==================== GAMES ====================
function getFinalPrice(game) {
  if (game.price === 0) return 0;
  if (game.discount > 0) return Math.round(game.price * (1 - game.discount / 100));
  return game.price;
}

function formatPrice(game) {
  if (game.price === 0) return '<span class="free">Бесплатно</span>';
  const final = getFinalPrice(game);
  if (game.discount > 0) {
    return `<span class="discount">-${game.discount}%</span><span class="old">${game.price} ₽</span>${final} ₽`;
  }
  return `${final} ₽`;
}

function renderGames(games = null) {
  const grid = document.getElementById('gamesGrid');
  let list = games || filterGamesList();

  if (list.length === 0) {
    grid.innerHTML = '<div class="empty-state"><p>Игры не найдены. Попробуйте изменить фильтры.</p></div>';
    return;
  }

  grid.innerHTML = list.map(g => `
    <div class="game-card" onclick="showGameDetails(${g.id})">
      ${g.discount > 0 ? `<div class="discount-badge">-${g.discount}%</div>` : ''}
      <button class="wishlist-btn ${wishlist.includes(g.id) ? 'active' : ''}" 
              onclick="event.stopPropagation(); toggleWishlist(${g.id})" 
              title="В желаемое">
        ${wishlist.includes(g.id) ? '❤️' : '🤍'}
      </button>
      <img class="game-card-img" src="${g.image}" alt="${g.title}" loading="lazy" 
           onerror="this.src='https://via.placeholder.com/460x215/2a475e/66c0f4?text=${encodeURIComponent(g.title)}'">
      <div class="game-card-body">
        <div class="game-card-title">${g.title}</div>
        <div class="game-card-genre">${g.genre} · ${g.developer}</div>
        <div class="game-card-footer">
          <div class="game-card-price ${g.price === 0 ? 'free' : ''}">${formatPrice(g)}</div>
          <div class="game-card-rating">★ ${g.rating}</div>
        </div>
      </div>
    </div>
  `).join('');
}

function filterGamesList() {
  let list = [...GAMES];
  const search = (document.getElementById('searchInput')?.value || '').toLowerCase();
  const genre = document.getElementById('genreFilter')?.value || '';
  const price = document.getElementById('priceFilter')?.value || '';
  const sort = document.getElementById('sortFilter')?.value || 'popular';
  const discountOnly = document.getElementById('discountOnly')?.checked || false;

  if (search) {
    list = list.filter(g => 
      g.title.toLowerCase().includes(search) || 
      g.genre.toLowerCase().includes(search) ||
      g.tags.some(t => t.toLowerCase().includes(search)) ||
      g.developer.toLowerCase().includes(search)
    );
  }

  if (genre) list = list.filter(g => g.genre === genre);
  if (discountOnly) list = list.filter(g => g.discount > 0);

  if (price === 'free') list = list.filter(g => g.price === 0);
  else if (price === 'low') list = list.filter(g => getFinalPrice(g) > 0 && getFinalPrice(g) <= 500);
  else if (price === 'mid') list = list.filter(g => getFinalPrice(g) > 500 && getFinalPrice(g) <= 2000);
  else if (price === 'high') list = list.filter(g => getFinalPrice(g) > 2000);

  if (currentCategory === 'new') list = list.filter(g => g.isNew);
  else if (currentCategory === 'sale') list = list.filter(g => g.discount > 0);
  else if (currentCategory === 'top') list = list.filter(g => g.isTop);
  else if (currentCategory === 'free') list = list.filter(g => g.price === 0);

  switch (sort) {
    case 'price-asc': list.sort((a, b) => getFinalPrice(a) - getFinalPrice(b)); break;
    case 'price-desc': list.sort((a, b) => getFinalPrice(b) - getFinalPrice(a)); break;
    case 'rating': list.sort((a, b) => b.rating - a.rating); break;
    case 'name': list.sort((a, b) => a.title.localeCompare(b.title)); break;
    default: list.sort((a, b) => (b.isTop ? 1 : 0) - (a.isTop ? 1 : 0) || b.rating - a.rating);
  }

  return list;
}

function filterGames() {
  renderGames();
}

function setCategory(cat) {
  currentCategory = cat;
  document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
  document.querySelector(`.cat-btn[data-cat="${cat}"]`)?.classList.add('active');
  renderGames();
}

// ==================== HERO ====================
const heroGames = GAMES.filter(g => g.discount >= 30 || g.isTop).slice(0, 5);
let heroIndex = 0;

function rotateHero() {
  const g = heroGames[heroIndex % heroGames.length];
  const hero = document.getElementById('heroBanner');
  const title = document.getElementById('heroTitle');
  const desc = document.getElementById('heroDesc');

  if (hero && g) {
    hero.style.backgroundImage = `url(${g.image})`;
    if (title) title.textContent = g.title;
    if (desc) desc.textContent = g.desc.slice(0, 120) + '...';
    const priceEl = hero.querySelector('.hero-price');
    if (priceEl) {
      if (g.price === 0) {
        priceEl.innerHTML = '<span class="new-price">Бесплатно</span>';
      } else if (g.discount > 0) {
        priceEl.innerHTML = `<span class="old-price">${g.price} ₽</span><span class="new-price">${getFinalPrice(g)} ₽</span>`;
      } else {
        priceEl.innerHTML = `<span class="new-price">${g.price} ₽</span>`;
      }
    }
    const buyBtn = hero.querySelector('.btn-primary');
    if (buyBtn) buyBtn.onclick = () => addToCart(g.id);
    const detailsBtn = hero.querySelector('.btn-secondary');
    if (detailsBtn) detailsBtn.onclick = () => showGameDetails(g.id);
  }
  heroIndex++;
}

// ==================== GAME DETAILS ====================
function showGameDetails(id) {
  const g = GAMES.find(x => x.id === id);
  if (!g) return;

  const body = document.getElementById('gameModalBody');
  const inLibrary = library.includes(id);
  const inCart = cart.includes(id);
  const inWish = wishlist.includes(id);

  body.innerHTML = `
    <div>
      <img class="game-modal-img" src="${g.image}" alt="${g.title}"
           onerror="this.src='https://via.placeholder.com/600x340/2a475e/66c0f4?text=${encodeURIComponent(g.title)}'">
    </div>
    <div class="game-modal-info">
      <h2>${g.title}</h2>
      <div class="game-modal-meta">
        <span class="meta-tag">${g.genre}</span>
        <span class="meta-tag">${g.developer}</span>
        <span class="meta-tag">${g.release}</span>
        <span class="meta-tag">★ ${g.rating}</span>
      </div>
      <p class="game-modal-desc">${g.desc}</p>
      <div class="game-modal-meta">
        ${g.tags.map(t => `<span class="meta-tag">${t}</span>`).join('')}
      </div>
      <div class="game-modal-price ${g.price === 0 ? 'free' : ''}">${formatPrice(g)}</div>
      <div class="game-modal-actions">
        ${inLibrary 
          ? '<button class="btn btn-secondary" disabled>✓ В библиотеке</button>'
          : inCart
            ? '<button class="btn btn-secondary" onclick="toggleCart()">В корзине — открыть</button>'
            : `<button class="btn btn-primary" onclick="addToCart(${g.id}); closeModal('gameModal')">В корзину</button>`
        }
        <button class="btn btn-secondary" onclick="toggleWishlist(${g.id}); showGameDetails(${g.id})">
          ${inWish ? '❤️ В желаемом' : '🤍 В желаемое'}
        </button>
      </div>
    </div>
    ${g.screenshots && g.screenshots.length ? `
      <div class="game-screenshots">
        ${g.screenshots.map(s => `<img src="${s}" alt="Screenshot" onerror="this.style.display='none'">`).join('')}
      </div>
    ` : ''}
  `;

  openModal('gameModal');
}

// ==================== CART ====================
function addToCart(id) {
  if (library.includes(id)) {
    showToast('Игра уже в библиотеке!', 'info');
    return;
  }
  if (cart.includes(id)) {
    showToast('Игра уже в корзине', 'info');
    return;
  }
  cart.push(id);
  saveCart();
  updateCartUI();
  showToast('Добавлено в корзину!', 'success');
}

function removeFromCart(id) {
  cart = cart.filter(x => x !== id);
  saveCart();
  updateCartUI();
}

function clearCart() {
  cart = [];
  saveCart();
  updateCartUI();
  showToast('Корзина очищена', 'info');
}

function saveCart() {
  localStorage.setItem('gg_cart', JSON.stringify(cart));
}

function updateCartUI() {
  document.getElementById('cartCount').textContent = cart.length;
  const container = document.getElementById('cartItems');
  if (cart.length === 0) {
    container.innerHTML = '<div class="empty-state"><p>Корзина пуста</p></div>';
    document.getElementById('cartTotal').textContent = '0 ₽';
    return;
  }

  let total = 0;
  container.innerHTML = cart.map(id => {
    const g = GAMES.find(x => x.id === id);
    if (!g) return '';
    const price = getFinalPrice(g);
    total += price;
    return `
      <div class="cart-item">
        <img src="${g.image}" alt="${g.title}" onerror="this.src='https://via.placeholder.com/80x45/2a475e/66c0f4?text=Game'">
        <div class="cart-item-info">
          <h4>${g.title}</h4>
          <span>${price === 0 ? 'Бесплатно' : price + ' ₽'}</span>
        </div>
        <button class="cart-item-remove" onclick="removeFromCart(${g.id})">×</button>
      </div>
    `;
  }).join('');
  document.getElementById('cartTotal').textContent = total === 0 ? 'Бесплатно' : total + ' ₽';
}

function toggleCart() {
  const sidebar = document.getElementById('cartSidebar');
  const overlay = document.getElementById('overlay');
  sidebar.classList.toggle('open');
  overlay.classList.toggle('open');
}

function checkout() {
  if (cart.length === 0) {
    showToast('Корзина пуста!', 'error');
    return;
  }
  cart.forEach(id => {
    if (!library.includes(id)) library.push(id);
  });
  const count = cart.length;
  cart = [];
  saveCart();
  localStorage.setItem('gg_library', JSON.stringify(library));
  updateCartUI();
  updateLibraryUI();
  toggleCart();
  showToast(`Покупка успешна! ${count} игр${count > 1 ? 'ы' : 'а'} добавлено в библиотеку`, 'success');
  updateProfileStats();
}

// ==================== WISHLIST ====================
function toggleWishlist(id) {
  if (wishlist.includes(id)) {
    wishlist = wishlist.filter(x => x !== id);
    showToast('Удалено из желаемого', 'info');
  } else {
    wishlist.push(id);
    showToast('Добавлено в желаемое!', 'success');
  }
  localStorage.setItem('gg_wishlist', JSON.stringify(wishlist));
  updateWishlistUI();
  renderGames();
}

function updateWishlistUI() {
  document.getElementById('wishlistCount').textContent = wishlist.length + ' игр';
  const grid = document.getElementById('wishlistGrid');
  if (wishlist.length === 0) {
    grid.innerHTML = '<div class="empty-state"><p>Список желаемого пуст. Добавьте игры из магазина!</p></div>';
    return;
  }
  const list = GAMES.filter(g => wishlist.includes(g.id));
  grid.innerHTML = list.map(g => `
    <div class="game-card" onclick="showGameDetails(${g.id})">
      ${g.discount > 0 ? `<div class="discount-badge">-${g.discount}%</div>` : ''}
      <button class="wishlist-btn active" onclick="event.stopPropagation(); toggleWishlist(${g.id})">❤️</button>
      <img class="game-card-img" src="${g.image}" alt="${g.title}" loading="lazy"
           onerror="this.src='https://via.placeholder.com/460x215/2a475e/66c0f4?text=${encodeURIComponent(g.title)}'">
      <div class="game-card-body">
        <div class="game-card-title">${g.title}</div>
        <div class="game-card-genre">${g.genre}</div>
        <div class="game-card-footer">
          <div class="game-card-price ${g.price === 0 ? 'free' : ''}">${formatPrice(g)}</div>
          <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); addToCart(${g.id})">В корзину</button>
        </div>
      </div>
    </div>
  `).join('');
}

// ==================== LIBRARY ====================
function updateLibraryUI() {
  document.getElementById('libraryCount').textContent = library.length + ' игр';
  document.getElementById('statGames').textContent = library.length;
  const grid = document.getElementById('libraryGrid');
  if (library.length === 0) {
    grid.innerHTML = '<div class="empty-state"><p>Библиотека пуста. Купите игры в магазине!</p></div>';
    return;
  }

  let list = GAMES.filter(g => library.includes(g.id));
  const search = (document.getElementById('librarySearch')?.value || '').toLowerCase();
  if (search) list = list.filter(g => g.title.toLowerCase().includes(search));

  if (libFilter === 'favorites') {
    // simulate favorites as first 3
    list = list.slice(0, Math.min(3, list.length));
  }

  grid.innerHTML = list.map(g => `
    <div class="library-card">
      <img src="${g.image}" alt="${g.title}" onerror="this.src='https://via.placeholder.com/120x68/2a475e/66c0f4?text=Game'">
      <div class="library-card-info">
        <h4>${g.title}</h4>
        <span>${g.genre} · ★ ${g.rating}</span>
      </div>
      <div class="library-card-actions">
        <button class="btn btn-sm btn-primary" onclick="playGame(${g.id})">▶ Играть</button>
      </div>
    </div>
  `).join('');
}

function filterLibrary() {
  updateLibraryUI();
}

function setLibFilter(f) {
  libFilter = f;
  document.querySelectorAll('.lib-filter').forEach(b => b.classList.remove('active'));
  document.querySelector(`.lib-filter[data-lib="${f}"]`)?.classList.add('active');
  updateLibraryUI();
}

function playGame(id) {
  const g = GAMES.find(x => x.id === id);
  showToast(`Запуск «${g.title}»... (демо)`, 'info');
}

// ==================== COMMUNITY ====================
function renderNews() {
  document.getElementById('newsList').innerHTML = NEWS.map(n => `
    <div class="news-item">
      <h4>${n.title}</h4>
      <p>${n.text}</p>
      <div class="date">${n.date}</div>
    </div>
  `).join('');
}

function renderFriends() {
  document.getElementById('friendsList').innerHTML = FRIENDS.map(f => `
    <div class="friend-item">
      <img class="friend-avatar" src="https://api.dicebear.com/7.x/avataaars/svg?seed=${f.seed}" alt="${f.name}">
      <div class="friend-info">
        <h5>${f.name}</h5>
        <span>${f.status}</span>
      </div>
    </div>
  `).join('');
}

function renderReviews() {
  document.getElementById('reviewsList').innerHTML = REVIEWS.map(r => `
    <div class="review-item">
      <div class="review-header">
        <span class="review-author">${r.author}</span>
        <span class="review-rating">${r.rating}</span>
      </div>
      <p class="review-text">${r.text}</p>
      <div class="review-game">об игре «${r.game}»</div>
    </div>
  `).join('');
}

// ==================== PROFILE ====================
function applyProfile() {
  document.getElementById('profileName').textContent = profile.name;
  document.getElementById('headerUsername').textContent = profile.name;
  document.getElementById('profileStatus').textContent = profile.status;
  document.getElementById('profileBio').textContent = profile.bio;

  const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(profile.avatarSeed)}`;
  document.getElementById('profileAvatar').src = avatarUrl;
  document.getElementById('headerAvatar').src = avatarUrl;

  document.getElementById('profileHeader').style.background = profile.themeColor;
  applyBanner(profile.banner);
  updateProfileStats();
  renderActivity();
}

function applyBanner(banner) {
  const el = document.getElementById('profileBanner');
  const banners = {
    default: 'linear-gradient(135deg, #1a1a2e, #16213e, #0f3460)',
    cyber: 'linear-gradient(135deg, #0f0c29, #302b63, #24243e)',
    forest: 'linear-gradient(135deg, #134e5e, #71b280)',
    space: 'linear-gradient(135deg, #0b0c10, #1f2833, #45a29e)',
    neon: 'linear-gradient(135deg, #fc00ff, #00dbde)',
    sunset: 'linear-gradient(135deg, #f12711, #f5af19)'
  };
  el.style.background = banners[banner] || banners.default;
}

function updateProfileStats() {
  document.getElementById('statGames').textContent = library.length;
  document.getElementById('statAchievements').textContent = Math.min(library.length * 2 + wishlist.length, 48);
  document.getElementById('statHours').textContent = library.length * 27 + Math.floor(Math.random() * 50);
}

function openCustomizeModal() {
  document.getElementById('customName').value = profile.name;
  document.getElementById('customStatus').value = profile.status;
  document.getElementById('customBio').value = profile.bio;
  document.getElementById('customAvatar').value = profile.avatarSeed;
  document.getElementById('customBanner').value = profile.banner;
  document.getElementById('avatarPreview').src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(profile.avatarSeed)}`;
  selectedThemeColor = profile.themeColor;
  document.querySelectorAll('.color-btn').forEach(b => {
    b.classList.toggle('active', b.dataset.color === profile.themeColor);
  });
  openModal('customizeModal');
}

function setupColorPicker() {
  document.querySelectorAll('.color-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.color-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectedThemeColor = btn.dataset.color;
    });
  });
}

function setupAvatarPreview() {
  const input = document.getElementById('customAvatar');
  input?.addEventListener('input', () => {
    const seed = input.value || 'Player';
    document.getElementById('avatarPreview').src = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(seed)}`;
  });
}

function saveProfile() {
  profile.name = document.getElementById('customName').value.trim() || 'Игрок';
  profile.status = document.getElementById('customStatus').value.trim() || 'Онлайн';
  profile.bio = document.getElementById('customBio').value.trim() || 'Добро пожаловать в мой профиль!';
  profile.avatarSeed = document.getElementById('customAvatar').value.trim() || 'Player';
  profile.banner = document.getElementById('customBanner').value;
  profile.themeColor = selectedThemeColor;

  localStorage.setItem('gg_profile', JSON.stringify(profile));
  applyProfile();
  closeModal('customizeModal');
  showToast('Профиль сохранён!', 'success');
}

function setupProfileTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const tab = btn.dataset.tab;
      const content = document.getElementById('profileTabContent');
      if (tab === 'activity') {
        renderActivity();
      } else if (tab === 'achievements') {
        content.innerHTML = `<div class="achievement-grid">${ACHIEVEMENTS.map(a => `
          <div class="achievement-card">
            <div class="icon">${a.icon}</div>
            <h4>${a.title}</h4>
            <p>${a.desc}</p>
          </div>
        `).join('')}</div>`;
      } else if (tab === 'badges') {
        content.innerHTML = `
          <div class="achievement-grid">
            <div class="achievement-card"><div class="icon">🥇</div><h4>Первопроходец</h4><p>Зарегистрировался в Grok Games</p></div>
            <div class="achievement-card"><div class="icon">🎯</div><h4>Снайпер</h4><p>Нашёл скрытые функции</p></div>
            <div class="achievement-card"><div class="icon">🌟</div><h4>Звезда</h4><p>Активный участник сообщества</p></div>
            <div class="achievement-card"><div class="icon">🛡️</div><h4>Защитник</h4><p>5 лет на платформе (скоро)</p></div>
          </div>
        `;
      }
    });
  });
}

function renderActivity() {
  const content = document.getElementById('profileTabContent');
  const activities = [];
  if (library.length > 0) {
    const last = GAMES.find(g => g.id === library[library.length - 1]);
    if (last) activities.push({ icon: '🛒', text: `Купил <strong>${last.title}</strong>`, time: 'Недавно' });
  }
  if (wishlist.length > 0) {
    const last = GAMES.find(g => g.id === wishlist[wishlist.length - 1]);
    if (last) activities.push({ icon: '❤️', text: `Добавил в желаемое <strong>${last.title}</strong>`, time: 'Недавно' });
  }
  activities.push({ icon: '👤', text: 'Обновил профиль', time: 'Сегодня' });
  activities.push({ icon: '🎮', text: 'Присоединился к Grok Games', time: 'В начале' });

  content.innerHTML = `<div class="activity-feed">${activities.map(a => `
    <div class="activity-item">
      <div class="activity-icon">${a.icon}</div>
      <div>
        <div class="activity-text">${a.text}</div>
        <div class="activity-time">${a.time}</div>
      </div>
    </div>
  `).join('')}</div>`;
}

// ==================== MODALS & UI ====================
function openModal(id) {
  document.getElementById(id).classList.add('open');
  document.getElementById('overlay').classList.add('open');
}

function closeModal(id) {
  document.getElementById(id).classList.remove('open');
  if (!document.getElementById('cartSidebar').classList.contains('open')) {
    document.getElementById('overlay').classList.remove('open');
  }
}

function closeAll() {
  document.querySelectorAll('.modal').forEach(m => m.classList.remove('open'));
  document.getElementById('cartSidebar').classList.remove('open');
  document.getElementById('overlay').classList.remove('open');
}

function showToast(msg, type = 'info') {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = msg;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(40px)';
    toast.style.transition = '0.3s';
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}
