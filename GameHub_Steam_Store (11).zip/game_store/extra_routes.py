# Extra feature routes - imported by app.py
from flask import render_template, request, redirect, url_for, session, flash, jsonify
from datetime import datetime, timedelta
import sqlite3

def register_extra_routes(app, helpers):
    get_db = helpers['get_db']
    get_current_user = helpers['get_current_user']
    login_required = helpers['login_required']
    admin_required = helpers['admin_required']
    get_final_price = helpers['get_final_price']
    unlock_achievement = helpers['unlock_achievement']
    check_achievements = helpers['check_achievements']
    notify = helpers['notify']

    @app.route('/achievements')
    @login_required
    def achievements():
        user = get_current_user()
        conn = get_db()
        all_ach = conn.execute('SELECT * FROM achievements ORDER BY points').fetchall()
        unlocked = {r['achievement_id'] for r in conn.execute(
            'SELECT achievement_id FROM user_achievements WHERE user_id=?', (user['id'],)).fetchall()}
        points = conn.execute(
            'SELECT COALESCE(SUM(a.points),0) FROM user_achievements ua '
            'JOIN achievements a ON a.id=ua.achievement_id WHERE ua.user_id=?', (user['id'],)
        ).fetchone()[0]
        conn.close()
        return render_template('achievements.html', user=user, achievements=all_ach,
                               unlocked=unlocked, points=points)

    @app.route('/notifications')
    @login_required
    def notifications_page():
        user = get_current_user()
        conn = get_db()
        items = conn.execute(
            'SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50',
            (user['id'],)
        ).fetchall()
        conn.execute('UPDATE notifications SET is_read=1 WHERE user_id=?', (user['id'],))
        conn.commit()
        conn.close()
        return render_template('notifications.html', user=user, notifications=items)

    @app.route('/api/notifications/count')
    def api_notif_count():
        if 'user_id' not in session:
            return jsonify({'count': 0})
        conn = get_db()
        c = conn.execute(
            'SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0',
            (session['user_id'],)
        ).fetchone()[0]
        conn.close()
        return jsonify({'count': c})

    @app.route('/collections')
    def collections_list():
        conn = get_db()
        cols = conn.execute(
            'SELECT c.*, COUNT(cg.game_id) as game_count FROM collections c '
            'LEFT JOIN collection_games cg ON c.id=cg.collection_id GROUP BY c.id'
        ).fetchall()
        conn.close()
        return render_template('collections.html', collections=cols, user=get_current_user())

    @app.route('/collection/<slug>')
    def collection_detail(slug):
        conn = get_db()
        col = conn.execute('SELECT * FROM collections WHERE slug=?', (slug,)).fetchone()
        if not col:
            flash('Коллекция не найдена', 'error')
            return redirect(url_for('collections_list'))
        games = conn.execute(
            'SELECT g.* FROM games g JOIN collection_games cg ON g.id=cg.game_id WHERE cg.collection_id=?',
            (col['id'],)
        ).fetchall()
        conn.close()
        return render_template('collection_detail.html', collection=col, games=games,
                               user=get_current_user(), get_final_price=get_final_price)

    @app.route('/subscription')
    def subscription_page():
        user = get_current_user()
        sub = None
        if user:
            conn = get_db()
            sub = conn.execute(
                'SELECT * FROM subscriptions WHERE user_id=? AND active=1', (user['id'],)
            ).fetchone()
            conn.close()
        return render_template('subscription.html', user=user, subscription=sub)

    @app.route('/subscription/buy', methods=['POST'])
    @login_required
    def buy_subscription():
        user = get_current_user()
        price = 399.0
        if user['balance'] < price:
            flash('Недостаточно средств (нужно 399 ₽)', 'error')
            return redirect(url_for('subscription_page'))
        conn = get_db()
        conn.execute('UPDATE users SET balance=balance-? WHERE id=?', (price, user['id']))
        expires = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
        existing = conn.execute('SELECT id FROM subscriptions WHERE user_id=?', (user['id'],)).fetchone()
        if existing:
            conn.execute(
                'UPDATE subscriptions SET active=1, expires_at=?, started_at=CURRENT_TIMESTAMP WHERE user_id=?',
                (expires, user['id'])
            )
        else:
            conn.execute(
                'INSERT INTO subscriptions (user_id, active, expires_at) VALUES (?,?,?)',
                (user['id'], 1, expires)
            )
        conn.commit()
        conn.close()
        unlock_achievement(user['id'], 'subscriber')
        notify(user['id'], 'GameHub Plus активирован!', 'Подписка до ' + expires, '/subscription')
        flash('Подписка GameHub Plus оформлена на 30 дней!', 'success')
        return redirect(url_for('subscription_page'))

    @app.route('/history')
    @login_required
    def purchase_history():
        user = get_current_user()
        conn = get_db()
        items = conn.execute(
            'SELECT ph.*, g.title, g.image_url FROM purchase_history ph '
            'JOIN games g ON ph.game_id=g.id WHERE ph.user_id=? ORDER BY ph.purchased_at DESC',
            (user['id'],)
        ).fetchall()
        conn.close()
        return render_template('history.html', user=user, items=items)

    @app.route('/compare')
    def compare_games():
        ids = request.args.getlist('id', type=int)[:3]
        games = []
        conn = get_db()
        if ids:
            placeholders = ','.join('?' * len(ids))
            games = conn.execute(
                'SELECT * FROM games WHERE id IN (' + placeholders + ')', ids
            ).fetchall()
        all_games = conn.execute('SELECT id, title FROM games ORDER BY title').fetchall()
        conn.close()
        return render_template('compare.html', games=games, all_games=all_games,
                               user=get_current_user(), get_final_price=get_final_price)

    @app.route('/guides')
    def guides_list():
        conn = get_db()
        guides = conn.execute(
            'SELECT g.*, games.title as game_title, games.image_url, u.username FROM guides g '
            'JOIN games ON g.game_id=games.id LEFT JOIN users u ON g.user_id=u.id '
            'ORDER BY g.created_at DESC'
        ).fetchall()
        conn.close()
        return render_template('guides.html', guides=guides, user=get_current_user())

    @app.route('/guide/add/<int:game_id>', methods=['GET', 'POST'])
    @login_required
    def add_guide(game_id):
        conn = get_db()
        game = conn.execute('SELECT * FROM games WHERE id=?', (game_id,)).fetchone()
        if not game:
            flash('Игра не найдена', 'error')
            conn.close()
            return redirect(url_for('store'))
        if request.method == 'POST':
            title = request.form.get('title', '').strip()
            body = request.form.get('body', '').strip()
            if title and body:
                conn.execute(
                    'INSERT INTO guides (game_id, user_id, title, body) VALUES (?,?,?,?)',
                    (game_id, session['user_id'], title, body)
                )
                conn.commit()
                flash('Гайд опубликован!', 'success')
                conn.close()
                return redirect(url_for('game_detail', game_id=game_id))
            flash('Заполните заголовок и текст', 'error')
        conn.close()
        return render_template('add_guide.html', game=game, user=get_current_user())

    @app.route('/review/like/<int:review_id>')
    @login_required
    def like_review(review_id):
        conn = get_db()
        try:
            conn.execute(
                'INSERT INTO review_likes (user_id, review_id) VALUES (?,?)',
                (session['user_id'], review_id)
            )
            conn.commit()
            flash('Лайк поставлен', 'success')
        except Exception:
            flash('Вы уже лайкнули этот отзыв', 'info')
        conn.close()
        return redirect(request.referrer or url_for('index'))

    @app.route('/status', methods=['POST'])
    @login_required
    def set_status():
        status = request.form.get('status', 'online')
        if status not in ('online', 'away', 'busy', 'offline'):
            status = 'online'
        conn = get_db()
        conn.execute('UPDATE users SET status=? WHERE id=?', (status, session['user_id']))
        conn.commit()
        conn.close()
        flash('Статус: ' + status, 'success')
        return redirect(request.referrer or url_for('profile'))

    @app.route('/cart/promo', methods=['POST'])
    @login_required
    def apply_promo():
        code = request.form.get('code', '').strip().upper()
        conn = get_db()
        promo = conn.execute(
            'SELECT * FROM promo_codes WHERE code=? AND active=1', (code,)
        ).fetchone()
        conn.close()
        if not promo:
            flash('Промокод не найден или неактивен', 'error')
        elif promo['used_count'] >= promo['max_uses']:
            flash('Промокод исчерпан', 'error')
        else:
            session['promo_code'] = code
            session['promo_discount'] = promo['discount_percent']
            flash('Промокод применён: −' + str(promo['discount_percent']) + '%', 'success')
        return redirect(url_for('cart'))

    @app.route('/admin')
    @login_required
    @admin_required
    def admin_panel():
        conn = get_db()
        stats = {
            'users': conn.execute('SELECT COUNT(*) FROM users').fetchone()[0],
            'games': conn.execute('SELECT COUNT(*) FROM games').fetchone()[0],
            'reviews': conn.execute('SELECT COUNT(*) FROM reviews').fetchone()[0],
            'purchases': conn.execute('SELECT COUNT(*) FROM purchase_history').fetchone()[0],
            'revenue': conn.execute('SELECT COALESCE(SUM(price_paid),0) FROM purchase_history').fetchone()[0],
        }
        games = conn.execute(
            'SELECT id, title, price, discount, rating FROM games ORDER BY id'
        ).fetchall()
        users = conn.execute(
            'SELECT id, username, email, balance, is_admin, created_at FROM users ORDER BY id DESC LIMIT 30'
        ).fetchall()
        news = conn.execute('SELECT * FROM news ORDER BY created_at DESC').fetchall()
        promos = conn.execute('SELECT * FROM promo_codes').fetchall()
        conn.close()
        return render_template('admin.html', user=get_current_user(), stats=stats,
                               games=games, users=users, news=news, promos=promos)

    @app.route('/admin/game/edit/<int:game_id>', methods=['GET', 'POST'])
    @login_required
    @admin_required
    def admin_edit_game(game_id):
        conn = get_db()
        game = conn.execute('SELECT * FROM games WHERE id=?', (game_id,)).fetchone()
        if not game:
            flash('Не найдено', 'error')
            conn.close()
            return redirect(url_for('admin_panel'))
        if request.method == 'POST':
            conn.execute(
                'UPDATE games SET title=?, price=?, discount=?, short_description=?, '
                'genre=?, age_rating=?, featured=?, trailer_url=? WHERE id=?',
                (request.form.get('title'), float(request.form.get('price', 0)),
                 int(request.form.get('discount', 0)), request.form.get('short_description'),
                 request.form.get('genre'), request.form.get('age_rating'),
                 1 if request.form.get('featured') else 0,
                 request.form.get('trailer_url', ''), game_id)
            )
            conn.commit()
            flash('Игра обновлена', 'success')
            conn.close()
            return redirect(url_for('admin_panel'))
        conn.close()
        return render_template('admin_edit_game.html', game=game, user=get_current_user())

    @app.route('/admin/news/add', methods=['POST'])
    @login_required
    @admin_required
    def admin_add_news():
        title = request.form.get('title', '').strip()
        body = request.form.get('body', '').strip()
        img = request.form.get('image_url', '')
        if title and body:
            conn = get_db()
            conn.execute('INSERT INTO news (title, body, image_url) VALUES (?,?,?)', (title, body, img))
            conn.commit()
            conn.close()
            flash('Новость добавлена', 'success')
        return redirect(url_for('admin_panel'))

    @app.route('/admin/promo/add', methods=['POST'])
    @login_required
    @admin_required
    def admin_add_promo():
        code = request.form.get('code', '').strip().upper()
        pct = int(request.form.get('discount_percent', 10))
        if code:
            conn = get_db()
            try:
                conn.execute('INSERT INTO promo_codes (code, discount_percent) VALUES (?,?)', (code, pct))
                conn.commit()
                flash('Промокод ' + code + ' создан', 'success')
            except Exception:
                flash('Код уже существует', 'error')
            conn.close()
        return redirect(url_for('admin_panel'))

    @app.route('/admin/make_admin/<int:uid>')
    @login_required
    @admin_required
    def make_admin(uid):
        conn = get_db()
        conn.execute('UPDATE users SET is_admin=1 WHERE id=?', (uid,))
        conn.commit()
        conn.close()
        flash('Права админа выданы', 'success')
        return redirect(url_for('admin_panel'))

    @app.route('/api/recommendations')
    @login_required
    def api_recommendations():
        user = get_current_user()
        conn = get_db()
        owned = conn.execute('SELECT game_id FROM library WHERE user_id=?', (user['id'],)).fetchall()
        owned_ids = [r[0] for r in owned]
        if not owned_ids:
            games = conn.execute(
                'SELECT id, title, image_url, price, discount, rating FROM games ORDER BY rating DESC LIMIT 6'
            ).fetchall()
        else:
            genres = conn.execute(
                'SELECT genre FROM games WHERE id IN (' + ','.join('?' * len(owned_ids)) + ')',
                owned_ids
            ).fetchall()
            tags = set()
            for g in genres:
                for t in (g[0] or '').split(','):
                    tags.add(t.strip())
            games = []
            for tag in list(tags)[:3]:
                ph = ','.join('?' * len(owned_ids))
                rows = conn.execute(
                    'SELECT id, title, image_url, price, discount, rating FROM games '
                    'WHERE genre LIKE ? AND id NOT IN (' + ph + ') ORDER BY rating DESC LIMIT 2',
                    [f'%{tag}%'] + owned_ids
                ).fetchall()
                games.extend(rows)
            games = games[:6]
        conn.close()
        return jsonify([{
            'id': g['id'], 'title': g['title'], 'image': g['image_url'],
            'price': get_final_price(g), 'rating': g['rating']
        } for g in games])

