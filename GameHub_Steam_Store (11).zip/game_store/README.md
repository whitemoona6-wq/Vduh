# GameStore — Магазин игр

## Быстрый старт

```bash
cd game_store
python -m venv venv

# Windows:
venv\Scripts\activate
# Linux/Mac:
# source venv/bin/activate

pip install -r requirements.txt

# ВАЖНО: удалите старую БД при первом запуске после обновления
del game_store.db
# Linux/Mac: rm -f game_store.db

python app.py
```

Откройте http://127.0.0.1:5000

## Если ошибка "no such table: games"

1. Остановите сервер (Ctrl+C)
2. Удалите файл `game_store.db` в папке с `app.py`
3. Запустите снова: `python app.py`

База создаётся автоматически при старте.

## Промокоды
GAMEHUB10 · STEAM20 · SALE30 · WELCOME15

## Админ
Зарегистрируйте пользователя с логином **admin**

## Docker
```bash
docker-compose up --build
```
